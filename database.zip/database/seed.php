<?php
/**
 * Database Auto-Setup & Seeder Script
 * Run this directly via browser: http://localhost/portfolio/database/seed.php
 * or command line: php database/seed.php
 */

require_once __DIR__ . '/../config/db.php';

$messages = [];
$errors   = [];

try {
    $schemaFile = __DIR__ . '/schema.sql';
    if (!file_exists($schemaFile)) {
        throw new Exception("schema.sql not found at " . $schemaFile);
    }

    // Connect to MySQL server (without specifying DB in case it does not exist)
    $rootDsn = sprintf('mysql:host=%s;port=%s;charset=utf8mb4', DB_HOST, DB_PORT);
    $rootPdo = new PDO($rootDsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    $rootPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
    $messages[] = "Database `" . DB_NAME . "` verified / created.";

    // Connect directly to the database
    $pdo = getDBConnection();

    // Read and execute schema statements
    $sqlContent = file_get_contents($schemaFile);

    // Split on queries (handling delimiter semicolons safely)
    $queries = array_filter(array_map('trim', explode(';', $sqlContent)));
    $count = 0;
    foreach ($queries as $q) {
        if (!empty($q)) {
            $pdo->exec($q);
            $count++;
        }
    }
    $messages[] = "Imported {$count} database statements successfully.";
    $messages[] = "Admin credentials set: Username: <strong>admin</strong> | Password: <strong>admin123</strong>";
    $messages[] = "Projects, technical skills, education, and sample approved comments seeded.";

} catch (Exception $e) {
    $errors[] = $e->getMessage();
}

if (php_sapi_name() === 'cli') {
    echo "\n=== Database Setup Result ===\n";
    foreach ($messages as $m) echo "✔ " . strip_tags($m) . "\n";
    foreach ($errors as $e) echo "❌ " . $e . "\n";
    exit(empty($errors) ? 0 : 1);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup · Anila S Portfolio</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 2rem 1rem; }
        .card { max-width: 650px; width: 100%; background: rgba(18, 18, 40, 0.95); border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 20px; padding: 2.5rem; box-shadow: 0 20px 50px rgba(0,0,0,0.6); }
        .item { padding: 0.75rem 1rem; border-radius: 8px; margin-bottom: 0.5rem; font-size: 0.92rem; }
        .success-item { background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.3); color: #6ee7b7; }
        .error-item { background: rgba(239, 68, 68, 0.12); border: 1px solid rgba(239, 68, 68, 0.3); color: #fca5a5; }
    </style>
</head>
<body>
    <div class="card">
        <h2 style="margin:0 0 1rem;font-size:1.6rem;color:#fff;display:flex;align-items:center;gap:0.75rem;">
            <span>⚡ Database Initialization</span>
            <span class="badge-pill <?= empty($errors) ? 'badge-success' : 'badge-danger' ?>">
                <?= empty($errors) ? 'Ready' : 'Error' ?>
            </span>
        </h2>

        <div style="margin: 1.5rem 0;">
            <?php foreach ($messages as $msg): ?>
                <div class="item success-item">✔ <?= $msg ?></div>
            <?php endforeach; ?>
            <?php foreach ($errors as $err): ?>
                <div class="item error-item">❌ <?= htmlspecialchars($err) ?></div>
            <?php endforeach; ?>
        </div>

        <?php if (empty($errors)): ?>
        <div style="background:rgba(139,92,246,0.1);border:1px solid rgba(139,92,246,0.25);border-radius:10px;padding:1rem 1.25rem;margin:1.5rem 0;font-size:0.9rem;">
            <div style="font-weight:700;color:#c4b5fd;margin-bottom:0.3rem;">🔑 Admin Credentials:</div>
            <div>Username: <code style="color:#fff;">admin</code> | Password: <code style="color:#fff;">admin123</code></div>
        </div>
        <?php endif; ?>

        <div style="display:flex;gap:1rem;margin-top:2rem;">
            <a href="../index.php" class="btn btn-primary" style="flex:1;">🚀 View Portfolio Homepage</a>
            <a href="../admin/login.php" class="btn btn-outline" style="flex:1;">🔐 Open Admin Panel</a>
        </div>
    </div>
</body>
</html>
