-- ============================================================
-- ANILA S PORTFOLIO - COMPLETE RELATIONAL DATABASE SCHEMA
-- Compatible with MySQL 5.7+ / MariaDB / phpMyAdmin (XAMPP)
-- Database Name: anila_portfolio
-- ============================================================

CREATE DATABASE IF NOT EXISTS `anila_portfolio` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `anila_portfolio`;

-- ------------------------------------------------------------
-- 1. Admins Table (Secure session authentication)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admins` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `email` VARCHAR(120) NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 2. Profile Information
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `profile_info` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `full_name` VARCHAR(100) NOT NULL,
    `title` VARCHAR(150) NOT NULL,
    `headline` VARCHAR(255) NOT NULL,
    `short_bio` TEXT NOT NULL,
    `email` VARCHAR(120) NOT NULL,
    `phone` VARCHAR(30) NULL,
    `github` VARCHAR(255) NOT NULL,
    `location` VARCHAR(100) DEFAULT 'Palakkad, Kerala, India',
    `resume_path` VARCHAR(255) DEFAULT 'Resume .pdf',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3. Education
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `education` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `degree` VARCHAR(150) NOT NULL,
    `institution` VARCHAR(200) NOT NULL,
    `location` VARCHAR(100) DEFAULT 'Palakkad, Kerala',
    `completion_date` VARCHAR(50) NOT NULL,
    `score` VARCHAR(50) NULL,
    `display_order` INT DEFAULT 0
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 4. Technical Skills
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `skills` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `category` VARCHAR(60) NOT NULL,
    `skill_name` VARCHAR(100) NOT NULL,
    `display_order` INT DEFAULT 0
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 5. Projects
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `projects` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(180) NOT NULL,
    `short_tagline` VARCHAR(255) NOT NULL,
    `description` TEXT NOT NULL,
    `overview` TEXT NULL,
    `problem_statement` TEXT NULL,
    `objectives` TEXT NULL,
    `implementation_details` TEXT NULL,
    `technologies` VARCHAR(500) NOT NULL,
    `thumbnail` VARCHAR(255) NULL,
    `video_url` VARCHAR(500) NULL,
    `report_pdf` VARCHAR(255) NULL,
    `github_url` VARCHAR(255) NULL,
    `demo_url` VARCHAR(255) NULL,
    `category` VARCHAR(60) DEFAULT 'Engineering',
    `is_featured` TINYINT(1) DEFAULT 1,
    `is_restricted` TINYINT(1) DEFAULT 0,
    `display_order` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 6. Project Resources / Gallery
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `project_resources` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `project_id` INT NOT NULL,
    `file_path` VARCHAR(255) NOT NULL,
    `file_type` ENUM('screenshot','document','other') DEFAULT 'screenshot',
    `caption` VARCHAR(255) NULL,
    `display_order` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 7. Project Access Requests
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `project_access_requests` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `project_id` INT NOT NULL,
    `visitor_name` VARCHAR(100) NOT NULL,
    `visitor_email` VARCHAR(120) NOT NULL,
    `reason` TEXT NOT NULL,
    `status` ENUM('pending','approved','rejected') DEFAULT 'pending',
    `admin_note` TEXT NULL,
    `ip_address` VARCHAR(45) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE,
    INDEX `idx_access_visitor` (`visitor_email`, `project_id`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 8. Project-Specific Comments (Per-project ID)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `project_comments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `project_id` INT NOT NULL,
    `author_name` VARCHAR(100) NOT NULL,
    `author_email` VARCHAR(120) NOT NULL,
    `comment_text` TEXT NOT NULL,
    `status` ENUM('pending','approved','rejected') DEFAULT 'pending',
    `ip_address` VARCHAR(45) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON DELETE CASCADE,
    INDEX `idx_comment_project` (`project_id`, `status`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 9. Contact Messages
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `contact_messages` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(120) NOT NULL,
    `subject` VARCHAR(200) NOT NULL,
    `message` TEXT NOT NULL,
    `is_read` TINYINT(1) DEFAULT 0,
    `ip_address` VARCHAR(45) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- SEED DATA (Authentic portfolio details for Anila S)
-- ------------------------------------------------------------

-- Default Admin (admin / admin123)
-- Password hash generated with password_hash('admin123', PASSWORD_DEFAULT)
INSERT INTO `admins` (`id`, `username`, `password_hash`, `email`, `full_name`)
VALUES (1, 'admin', '$2y$10$UoW1R2u88j0W1F6.Fsz99.OqYI7kKov6K2Q8Z87N/s2n6u.a7r46a', 'anila994785@gmail.com', 'Anila S')
ON DUPLICATE KEY UPDATE `username`=`username`;

-- Profile Information
INSERT INTO `profile_info` (`id`, `full_name`, `title`, `headline`, `short_bio`, `email`, `phone`, `github`, `location`, `resume_path`)
VALUES (
    1,
    'Anila S',
    'Information Technology Engineer & Developer',
    'Building intelligent systems, distributed architectures, and efficient software solutions.',
    'Information Technology graduate from Government Engineering College Sreekrishnapuram. Passionate about systems programming, data compression, swarm robotics, and full-stack engineering with a focus on practical problem solving.',
    'anila994785@gmail.com',
    '9961542447',
    'https://github.com/cypherX15',
    'Palakkad, Kerala, India',
    'Resume .pdf'
)
ON DUPLICATE KEY UPDATE `full_name`=VALUES(`full_name`), `headline`=VALUES(`headline`), `short_bio`=VALUES(`short_bio`);

-- Education
DELETE FROM `education`;
INSERT INTO `education` (`degree`, `institution`, `location`, `completion_date`, `score`, `display_order`)
VALUES
('B.Tech in Information Technology', 'Government Engineering College Sreekrishnapuram', 'Palakkad, Kerala', '2022 – 2026', 'CGPA 8.43', 1),
('Higher Secondary Education (Plus Two)', 'Government Moyan Model Girls Higher Secondary School', 'Palakkad, Kerala', '2020 – 2022', '97%', 2);

-- Skills (Clean categorisation, strictly no percentages)
DELETE FROM `skills`;
INSERT INTO `skills` (`category`, `skill_name`, `display_order`)
VALUES
('Programming Languages', 'Python', 1),
('Programming Languages', 'Java', 2),
('Programming Languages', 'C', 3),
('Programming Languages', 'C++', 4),
('Programming Languages', 'Dart', 5),
('Programming Languages', 'PHP', 6),

('Web Development', 'HTML5 & CSS3', 7),
('Web Development', 'JavaScript', 8),
('Web Development', 'Flask', 9),
('Web Development', 'REST APIs', 10),

('App Development', 'Flutter', 11),
('App Development', 'Android (Java/Kotlin)', 12),

('Database and Tools', 'MySQL', 13),
('Database and Tools', 'Git & GitHub', 14),
('Database and Tools', 'Wireshark', 15),
('Database and Tools', 'Nmap', 16),
('Database and Tools', 'PyQt', 17);

-- Projects
DELETE FROM `projects`;
INSERT INTO `projects` (
    `id`, `title`, `short_tagline`, `description`, `overview`, `problem_statement`, `objectives`, `implementation_details`,
    `technologies`, `thumbnail`, `video_url`, `report_pdf`, `github_url`, `demo_url`, `category`, `is_featured`, `is_restricted`, `display_order`
) VALUES
(
    1,
    'Text-Based PDF Compression Algorithm',
    'High-efficiency custom compressor combining MessagePack and LZMA with up to 90–95% file size reduction.',
    'A custom text-centric PDF compression pipeline built with MessagePack and LZMA that strips redundant structure, serializes layout tokens, and achieves extreme compression ratios while guaranteeing 100% text fidelity.',
    'Standard PDF compression methods treat documents generically without leveraging the repetitive token semantics of text. This system isolates text streams, normalizes typographic definitions, and uses a two-phase byte packing and LZMA dictionary pass to drastically cut bandwidth and archival footprints.',
    'Conventional enterprise document archives generate gigabytes of repetitive text-based invoices, reports, and books. Generic deflate compression rarely exceeds 50-60% compression on raw text-heavy streams.',
    'Isolate and tokenize text stream layers from complex PDF structures.\nImplement MessagePack semantic serialisation for textual tokens and coordinate metadata.\nApply secondary LZMA compression pass to achieve 90-95% compression.\nBuild a cross-platform PyQt desktop viewer and Flask web service for instant decompression.',
    '1. Parsing engine reads raw object trees and extracts font/text operands.\n2. Serializer packs coordinates, characters, and encoding tables with MessagePack.\n3. High-preset LZMA algorithm strips redundant entropy.\n4. Reconstructor synthesizes standard compliant viewing buffers in real-time.',
    'Python, MessagePack, LZMA, PyQt, Flask',
    'project_pdf_compression.svg',
    '',
    'Resume .pdf',
    'https://github.com/cypherX15',
    '',
    'Systems & Algorithms',
    1,
    1,
    1
),
(
    2,
    'Distributed Swarm Robotic System for Waste Detection and Collection',
    'Autonomous multi-agent robotics framework utilizing decentralized peer-to-peer coordination and real-time computer vision.',
    'A scalable multi-agent robotic system engineered for autonomous waste identification and pickup in unstructured environments. Features dynamic area partitioning, peer-to-peer consensus, and vision-based object tracking.',
    'Autonomous waste collection in public areas is traditionally hampered by single-point-of-failure centralized controllers and poor scaling. This project proves a resilient, mesh-networked swarm approach where individual agents negotiate coverage zones and recover seamlessly if one robot fails.',
    'Centralized automated robotic cleaners suffer from bottlenecks, wireless range cut-offs, and complete stoppage on coordinator failure.',
    'Design decentralized P2P messaging protocol for real-time robotic agent consensus.\nImplement dynamic Voronoi-inspired spatial partitioning for optimal coverage.\nIntegrate onboard lightweight computer vision models for waste categorization.\nDemonstrate robust fault-tolerance when active nodes drop offline.',
    'Implemented peer-to-peer communication using UDP broadcast discovery and lightweight gossip protocols. Computer vision pipelines preprocess camera feeds to segment target objects, notifying neighboring nodes to prevent duplicate collection passes.',
    'Python, P2P Networking, Computer Vision, Robotics, OpenCV',
    'project_swarm_robotics.svg',
    '',
    '',
    'https://github.com/cypherX15',
    '',
    'Robotics & Distributed Systems',
    1,
    0,
    2
);

-- Project Resources (Sample screenshots)
DELETE FROM `project_resources`;
INSERT INTO `project_resources` (`project_id`, `file_path`, `file_type`, `caption`, `display_order`)
VALUES
(1, 'screenshot_compression_ui.svg', 'screenshot', 'PyQt Desktop Viewer & Compression Benchmark', 1),
(1, 'screenshot_compression_stats.svg', 'screenshot', 'Compression Ratio & Execution Benchmark Graph', 2),
(2, 'screenshot_swarm_arena.svg', 'screenshot', 'Swarm Simulation Grid & Dynamic Partitioning', 1),
(2, 'screenshot_swarm_vision.svg', 'screenshot', 'Autonomous Vision Tracking & Target Classification', 2);

-- Sample Approved Comments for Project 1 & 2
DELETE FROM `project_comments`;
INSERT INTO `project_comments` (`project_id`, `author_name`, `author_email`, `comment_text`, `status`, `created_at`)
VALUES
(1, 'Dr. K. Raman', 'k.raman@gecskp.ac.in', 'Impressive compression benchmark results. The MessagePack integration with LZMA yields substantial savings on dense technical texts.', 'approved', '2026-10-15 11:20:00'),
(2, 'Siddharth Nair', 'siddharth@example.com', 'The peer-to-peer gossip mechanism for decentralized task partitioning is exceptionally well thought out.', 'approved', '2026-10-22 16:45:00');
