<?php
/**
 * Database Configuration & Connection Manager
 * Standard XAMPP environment: 127.0.0.1, user 'root', blank password.
 */

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'anila_portfolio');
define('DB_USER', 'root');
define('DB_PASS', '');

/**
 * Returns a singleton PDO database connection instance.
 * Automatically attempts database creation if not yet initialized.
 */
function getDBConnection(): PDO {
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 5,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // If database does not exist (error code 1049), auto-create and seed
            if ($e->getCode() == 1049 || str_contains($e->getMessage(), 'Unknown database')) {
                try {
                    $rootDsn = sprintf('mysql:host=%s;port=%s;charset=utf8mb4', DB_HOST, DB_PORT);
                    $rootPdo = new PDO($rootDsn, DB_USER, DB_PASS, $options);
                    $rootPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");

                    // Connect and import schema
                    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
                    $schemaPath = __DIR__ . '/../database/schema.sql';
                    if (file_exists($schemaPath)) {
                        $sql = file_get_contents($schemaPath);
                        $pdo->exec($sql);
                    }
                    return $pdo;
                } catch (Exception $inner) {
                    // Fall through
                }
            }

            // Clean, professional XAMPP instructions page
            die('<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup Required · Anila S Portfolio</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 2rem 1rem; }
        .setup-card { max-width: 650px; background: rgba(18, 18, 40, 0.95); border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 20px; padding: 2.5rem; box-shadow: 0 20px 50px rgba(0,0,0,0.6); }
        code { background: rgba(255,255,255,0.08); padding: 2px 8px; border-radius: 4px; color: #a78bfa; font-family: monospace; }
        ol { padding-left: 1.25rem; margin: 1.5rem 0; color: #a0a0c0; line-height: 1.8; }
        li { margin-bottom: 0.5rem; }
    </style>
</head>
<body>
    <div class="setup-card">
        <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:1rem;">
            <div style="width:12px;height:12px;border-radius:50%;background:#ef4444;box-shadow:0 0 10px #ef4444;"></div>
            <h2 style="margin:0;font-size:1.4rem;color:#fff;">MySQL Database Setup Required</h2>
        </div>
        <p style="color:#a0a0c0;font-size:0.95rem;">
            Could not connect to MySQL at <code>' . htmlspecialchars(DB_HOST) . ':' . htmlspecialchars(DB_PORT) . '</code>.
        </p>

        <ol>
            <li>Open the <strong>XAMPP Control Panel</strong> and click <strong>Start</strong> next to <strong>MySQL</strong> and <strong>Apache</strong>.</li>
            <li>Once MySQL is running, open <a href="database/seed.php" style="color:#22d3ee;font-weight:600;">database/seed.php</a> in your browser to auto-import the database.</li>
            <li>Alternatively, open <strong>phpMyAdmin</strong> (<a href="http://localhost/phpmyadmin" target="_blank" style="color:#22d3ee;">http://localhost/phpmyadmin</a>) and import <code>database/schema.sql</code>.</li>
        </ol>

        <div style="display:flex;gap:1rem;margin-top:2rem;">
            <a href="database/seed.php" class="btn btn-primary" style="flex:1;">⚡ Run Database Setup &amp; Seeder</a>
            <a href="index.php" class="btn btn-outline" style="flex:1;">🔄 Retry Connection</a>
        </div>
    </div>
</body>
</html>');
        }
    }

    return $pdo;
}
