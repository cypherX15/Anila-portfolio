<?php
/**
 * Administrator — Profile & About Section Management
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();
$pdo = getDBConnection();

$actionMsg   = '';
$actionError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $actionError = 'Security token mismatch. Please refresh and try again.';
    } else {
        $full_name  = trim($_POST['full_name']  ?? '');
        $title      = trim($_POST['title']      ?? '');
        $headline   = trim($_POST['headline']   ?? '');
        $short_bio  = trim($_POST['short_bio']  ?? '');
        $bio        = trim($_POST['bio']        ?? '');
        $email      = trim($_POST['email']      ?? '');
        $phone      = trim($_POST['phone']      ?? '');
        $github     = trim($_POST['github']     ?? '');
        $location   = trim($_POST['location']   ?? '');

        if (empty($full_name) || empty($title)) {
            $actionError = 'Full name and professional title are required.';
        } else {
            try {
                // Resume upload
                $resumePath = null;
                if (isset($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
                    $file = $_FILES['resume'];
                    $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    if (!in_array($ext, ['pdf','doc','docx'], true)) {
                        throw new RuntimeException('Only PDF, DOC, or DOCX files allowed for resume.');
                    }
                    if ($file['size'] > 10 * 1024 * 1024) {
                        throw new RuntimeException('Resume file must be under 10MB.');
                    }
                    $uploadDir = __DIR__ . '/../uploads/';
                    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                    $filename = 'resume_' . time() . '.' . $ext;
                    if (!move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
                        throw new RuntimeException('Failed to save resume file.');
                    }
                    $resumePath = $filename;
                }

                $exists = (int)$pdo->query("SELECT COUNT(*) FROM profile_info")->fetchColumn();
                if ($exists > 0) {
                    $cur = $pdo->query("SELECT resume_path FROM profile_info LIMIT 1")->fetch(PDO::FETCH_ASSOC);
                    $resumePath = $resumePath ?? ($cur['resume_path'] ?? '');
                    $stmt = $pdo->prepare("
                        UPDATE profile_info SET
                            full_name = ?, title = ?, headline = ?, short_bio = ?, bio = ?,
                            email = ?, phone = ?, github = ?, location = ?, resume_path = ?,
                            updated_at = NOW()
                        LIMIT 1
                    ");
                    $stmt->execute([$full_name, $title, $headline, $short_bio, $bio, $email, $phone, $github, $location, $resumePath]);
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO profile_info (full_name, title, headline, short_bio, bio, email, phone, github, location, resume_path, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $stmt->execute([$full_name, $title, $headline, $short_bio, $bio, $email, $phone, $github, $location, $resumePath]);
                }
                $actionMsg = 'Profile and About Me section updated successfully.';
            } catch (Exception $e) {
                $actionError = 'Error: ' . $e->getMessage();
            }
        }
    }
}

$profile = $pdo->query("SELECT * FROM profile_info LIMIT 1")->fetch(PDO::FETCH_ASSOC);
if (!$profile) {
    $profile = [
        'full_name'   => 'Anila S',
        'title'       => 'Information Technology Engineer & Developer',
        'headline'    => 'Curious minds create. Ideas evolve. Technology transforms.',
        'short_bio'   => 'Curious about technology, drawn to creative ideas, and always exploring new ways to turn concepts into meaningful digital creations.',
        'bio'         => "I am an Information Technology Engineer with a focus on writing clean, high-performance software and exploring practical distributed technologies.\n\nMy work spans low-level algorithm optimization like token-based document compression, autonomous multi-agent robotics coordination, and modern web application development.",
        'email'       => 'anila994785@gmail.com',
        'phone'       => '',
        'github'      => 'https://github.com/cypherX15',
        'location'    => 'Palakkad, Kerala, India',
        'resume_path' => 'Resume .pdf',
    ];
}

// If bio is empty or contains the old student paragraph, supply default
if (empty($profile['bio'])) {
    $profile['bio'] = "I am an Information Technology Engineer with a focus on writing clean, high-performance software and exploring practical distributed technologies.\n\nMy work spans low-level algorithm optimization like token-based document compression, autonomous multi-agent robotics coordination, and modern web application development.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile &amp; About · Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
</head>
<body>
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <main class="admin-main">
        <header class="topbar">
            <h1 class="topbar-title">
                <i class="fas fa-user-circle" style="color:var(--accent);"></i>
                Profile &amp; About Me Editor
            </h1>
            <a href="../index.php#about" target="_blank" class="btn btn-secondary btn-sm">
                <i class="fas fa-external-link-alt"></i> View on Site
            </a>
        </header>

        <div class="admin-content" style="max-width:980px;">
            <?php if (!empty($actionMsg)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?= e($actionMsg) ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($actionError)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?= e($actionError) ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">

                <!-- 1. Identity & Hero Panel -->
                <div class="panel">
                    <div class="panel-header">
                        <span class="panel-title"><i class="fas fa-id-card" style="color:var(--accent);margin-right:0.5rem;"></i> Identity &amp; Hero Headline</span>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="full_name">Full Name *</label>
                            <input type="text" id="full_name" name="full_name" class="form-control" required
                                value="<?= e($profile['full_name'] ?? '') ?>" placeholder="Anila S">
                        </div>
                        <div class="form-group">
                            <label for="title">Professional Title *</label>
                            <input type="text" id="title" name="title" class="form-control" required
                                value="<?= e($profile['title'] ?? '') ?>" placeholder="Information Technology Engineer & Developer">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="headline">Hero Headline</label>
                        <input type="text" id="headline" name="headline" class="form-control"
                            value="<?= e($profile['headline'] ?? '') ?>"
                            placeholder="Curious minds create. Ideas evolve. Technology transforms.">
                        <p class="form-hint">Displayed in large bold text on the homepage hero section.</p>
                    </div>
                    <div class="form-group">
                        <label for="short_bio">Hero Subtitle / Tagline</label>
                        <textarea id="short_bio" name="short_bio" class="form-control" rows="2"
                            placeholder="Short 1-2 sentence tagline under the hero headline."><?= e($profile['short_bio'] ?? '') ?></textarea>
                        <p class="form-hint">Displayed right beneath the hero headline.</p>
                    </div>
                </div>

                <!-- 2. About Me Section Content Panel (NEW FEATURE) -->
                <div class="panel">
                    <div class="panel-header">
                        <span class="panel-title"><i class="fas fa-address-card" style="color:var(--warning);margin-right:0.5rem;"></i> "About Me" Section Content</span>
                        <span style="font-size:0.8rem;color:var(--text-muted);">Appears under the "Background &bull; About Me" section on the homepage</span>
                    </div>
                    <div class="form-group">
                        <label for="bio">About Me Description *</label>
                        <textarea id="bio" name="bio" class="form-control" rows="6" style="line-height:1.6;font-size:0.95rem;"
                            placeholder="Enter the text for your About Me section. You can separate paragraphs with a blank line."><?= e($profile['bio'] ?? '') ?></textarea>
                        <p class="form-hint">
                            <i class="fas fa-info-circle"></i> Separate paragraphs with an empty line. It will format automatically into elegant editorial paragraphs on the homepage.
                        </p>
                    </div>
                </div>

                <!-- 3. Contact & Social Links Panel -->
                <div class="panel">
                    <div class="panel-header">
                        <span class="panel-title"><i class="fas fa-address-book" style="color:var(--cyan);margin-right:0.5rem;"></i> Contact &amp; Links</span>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" class="form-control"
                                value="<?= e($profile['email'] ?? '') ?>" placeholder="you@example.com">
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number (Optional)</label>
                            <input type="text" id="phone" name="phone" class="form-control"
                                value="<?= e($profile['phone'] ?? '') ?>" placeholder="+91 99615 42447">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="github">GitHub Profile URL</label>
                            <input type="url" id="github" name="github" class="form-control"
                                value="<?= e($profile['github'] ?? '') ?>" placeholder="https://github.com/cypherX15">
                        </div>
                        <div class="form-group">
                            <label for="location">Location</label>
                            <input type="text" id="location" name="location" class="form-control"
                                value="<?= e($profile['location'] ?? '') ?>" placeholder="Palakkad, Kerala, India">
                        </div>
                    </div>
                </div>

                <!-- 4. Resume Panel -->
                <div class="panel">
                    <div class="panel-header">
                        <span class="panel-title"><i class="fas fa-file-pdf" style="color:var(--danger);margin-right:0.5rem;"></i> Resume / CV</span>
                    </div>
                    <?php if (!empty($profile['resume_path'])): ?>
                        <?php 
                            $resumeHref = file_exists(__DIR__ . '/../uploads/' . $profile['resume_path'])
                                ? '../uploads/' . e($profile['resume_path'])
                                : '../' . e($profile['resume_path']);
                        ?>
                        <div style="display:flex;align-items:center;gap:0.75rem;padding:0.75rem 1rem;background:var(--bg-dark);border:1px solid var(--border-subtle);border-radius:8px;margin-bottom:1rem;">
                            <i class="fas fa-file-pdf" style="color:var(--danger);font-size:1.2rem;"></i>
                            <span style="font-size:0.9rem;">Current resume: <strong><?= e($profile['resume_path']) ?></strong></span>
                            <a href="<?= $resumeHref ?>" target="_blank" class="btn btn-secondary btn-sm" style="margin-left:auto;">
                                <i class="fas fa-eye"></i> View Current
                            </a>
                        </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="resume">Upload New Resume (PDF / DOC)</label>
                        <input type="file" id="resume" name="resume" class="form-control" accept=".pdf,.doc,.docx">
                        <p class="form-hint">Leave blank to retain current file. Max size 10MB.</p>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary" style="font-size:1rem;padding:0.8rem 2.2rem;">
                    <i class="fas fa-save"></i> Save Profile &amp; About Me Changes
                </button>
            </form>
        </div>
    </main>
</body>
</html>
