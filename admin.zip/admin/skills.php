<?php
/**
 * Administrator — Technical Skills Management
 * Add, edit, reorder, or delete skills by category.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();
$pdo = getDBConnection();

$actionMsg   = '';
$actionError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $actionError = 'Security token invalid. Please refresh.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'save') {
            $id            = !empty($_POST['id']) ? (int)$_POST['id'] : null;
            $category      = trim($_POST['category'] ?? 'Programming Languages');
            $skill_name    = trim($_POST['skill_name'] ?? '');
            $display_order = (int)($_POST['display_order'] ?? 0);

            if (empty($skill_name)) {
                $actionError = 'Skill name is required.';
            } else {
                if ($id) {
                    $stmt = $pdo->prepare("UPDATE skills SET category = ?, skill_name = ?, display_order = ? WHERE id = ?");
                    $stmt->execute([$category, $skill_name, $display_order, $id]);
                    $actionMsg = 'Skill updated successfully.';
                } else {
                    $stmt = $pdo->prepare("INSERT INTO skills (category, skill_name, display_order) VALUES (?, ?, ?)");
                    $stmt->execute([$category, $skill_name, $display_order]);
                    $actionMsg = 'New skill added.';
                }
            }
        }

        if ($action === 'delete') {
            $delId = (int)($_POST['id'] ?? 0);
            if ($delId > 0) {
                $pdo->prepare("DELETE FROM skills WHERE id = ?")->execute([$delId]);
                $actionMsg = 'Skill removed.';
            }
        }
    }
}

$skills = $pdo->query("SELECT * FROM skills ORDER BY category ASC, display_order ASC")->fetchAll();

$editSkill = null;
if (isset($_GET['edit'])) {
    $eId = (int)$_GET['edit'];
    $s = $pdo->prepare("SELECT * FROM skills WHERE id = ? LIMIT 1");
    $s->execute([$eId]);
    $editSkill = $s->fetch();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Technical Skills · Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
</head>
<body>
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <main class="admin-main">
        <header class="topbar">
            <h1 class="topbar-title">Technical Skills Management</h1>
            <a href="skills.php#editor" class="btn btn-primary btn-sm">+ Add Skill</a>
        </header>

        <div class="admin-content">
            <?php if (!empty($actionMsg)): ?>
                <div style="background:rgba(16,185,129,0.15);border:1px solid var(--accent);color:#a7f3d0;padding:1rem;border-radius:8px;margin-bottom:1.5rem;">
                    <i class="fas fa-check-circle"></i> <?= e($actionMsg) ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($actionError)): ?>
                <div style="background:rgba(239,68,68,0.15);border:1px solid var(--danger);color:#fca5a5;padding:1rem;border-radius:8px;margin-bottom:1.5rem;">
                    <i class="fas fa-exclamation-circle"></i> <?= e($actionError) ?>
                </div>
            <?php endif; ?>

            <!-- Skill Editor -->
            <div id="editor" class="panel">
                <div class="panel-header">
                    <h2 class="panel-title"><?= $editSkill ? 'Edit Skill: ' . e($editSkill['skill_name']) : 'Add New Technical Skill' ?></h2>
                    <?php if ($editSkill): ?>
                        <a href="skills.php" class="btn btn-outline btn-sm">Cancel</a>
                    <?php endif; ?>
                </div>

                <form method="POST" action="skills.php#editor">
                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                    <input type="hidden" name="action" value="save">
                    <?php if ($editSkill): ?>
                        <input type="hidden" name="id" value="<?= $editSkill['id'] ?>">
                    <?php endif; ?>

                    <div style="display:grid;grid-template-columns:1.2fr 1.5fr 0.8fr;gap:1.25rem;">
                        <div class="form-group">
                            <label class="form-label">Category *</label>
                            <select name="category" class="form-control" required>
                                <?php
                                $categories = ['Programming Languages', 'Web Development', 'App Development', 'Database and Tools'];
                                foreach ($categories as $cat):
                                ?>
                                    <option value="<?= $cat ?>" <?= ($editSkill && $editSkill['category'] === $cat) ? 'selected' : '' ?>>
                                        <?= $cat ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Skill Name *</label>
                            <input type="text" name="skill_name" class="form-control" required
                                   value="<?= e($editSkill['skill_name'] ?? '') ?>" placeholder="e.g. Python, Flutter, MySQL">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Display Order</label>
                            <input type="number" name="display_order" class="form-control"
                                   value="<?= (int)($editSkill['display_order'] ?? 0) ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="margin-top:0.5rem;">
                        <?= $editSkill ? 'Save Changes' : 'Add Skill' ?>
                    </button>
                </form>
            </div>

            <!-- Skills List -->
            <div class="panel">
                <div class="panel-header">
                    <h2 class="panel-title">Existing Skills (<?= count($skills) ?>)</h2>
                </div>

                <div class="data-table-wrap">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Skill Name</th>
                                <th>Order</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($skills as $s): ?>
                                <tr>
                                    <td><span class="badge badge-warning"><?= e($s['category']) ?></span></td>
                                    <td><strong><?= e($s['skill_name']) ?></strong></td>
                                    <td><?= (int)$s['display_order'] ?></td>
                                    <td>
                                        <div style="display:flex;gap:0.4rem;">
                                            <a href="skills.php?edit=<?= $s['id'] ?>#editor" class="btn btn-outline btn-sm">Edit</a>
                                            <form method="POST" action="skills.php" onsubmit="return confirm('Delete this skill?');" style="display:inline;">
                                                <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?= $s['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
