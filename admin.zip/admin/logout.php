<?php
require_once __DIR__ . '/../includes/auth_check.php';

unset($_SESSION['admin_logged_in']);
unset($_SESSION['admin_id']);
unset($_SESSION['admin_username']);
unset($_SESSION['admin_name']);

header('Location: login.php?msg=logged_out');
exit;
