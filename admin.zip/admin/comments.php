<?php
/**
 * Administrator — Project Comments Management
 * View, approve, reject, delete comments grouped by project.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();
$pdo = getDBConnection();

$actionMsg = '';

// Handle Moderation Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $action = $_POST['action'] ?? '';
        $id     = (int)($_POST['id'] ?? 0);

        if ($action === 'approve' && $id > 0) {
            $pdo->prepare("UPDATE project_comments SET status = 'approved' WHERE id = ?")->execute([$id]);
            $actionMsg = 'Comment approved and published to the project page.';
        }

        if ($action === 'reject' && $id > 0) {
            $pdo->prepare("UPDATE project_comments SET status = 'rejected' WHERE id = ?")->execute([$id]);
            $actionMsg = 'Comment rejected.';
        }

        if ($action === 'delete' && $id > 0) {
            $pdo->prepare("DELETE FROM project_comments WHERE id = ?")->execute([$id]);
            $actionMsg = 'Comment deleted permanently.';
        }
    }
}

// Fetch all projects for grouping filter
$projectsList = $pdo->query("SELECT id, title FROM projects ORDER BY title ASC")->fetchAll();

$filterProject = isset($_GET['project_id']) && (int)$_GET['project_id'] > 0 ? (int)$_GET['project_id'] : null;

if ($filterProject) {
    $cStmt = $pdo->prepare("
        SELECT c.*, p.title AS project_title
        FROM project_comments c
        JOIN projects p ON c.project_id = p.id
        WHERE c.project_id = ?
        ORDER BY FIELD(c.status,'pending','approved','rejected'), c.created_at DESC
    ");
    $cStmt->execute([$filterProject]);
} else {
    $cStmt = $pdo->query("
        SELECT c.*, p.title AS project_title
        FROM project_comments c
        JOIN projects p ON c.project_id = p.id
        ORDER BY FIELD(c.status,'pending','approved','rejected'), c.created_at DESC
    ");
}
$comments = $cStmt->fetchAll();

$pendingCount  = count(array_filter($comments, fn($c) => $c['status'] === 'pending'));
$approvedCount = count(array_filter($comments, fn($c) => $c['status'] === 'approved'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Comments · Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
</head>
<body>
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <main class="admin-main">
        <header class="topbar">
            <h1 class="topbar-title">Project Comments Moderation</h1>
            <div style="display:flex;align-items:center;gap:1rem;">
                <span style="color:var(--cyan);font-weight:600;font-size:0.9rem;">
                    <?= $pendingCount ?> Awaiting Approval
                </span>
            </div>
        </header>

        <div class="admin-content">
            <?php if (!empty($actionMsg)): ?>
                <div style="background:rgba(16,185,129,0.15);border:1px solid var(--accent);color:#a7f3d0;padding:1rem;border-radius:8px;margin-bottom:1.5rem;">
                    <i class="fas fa-check-circle"></i> <?= e($actionMsg) ?>
                </div>
            <?php endif; ?>

            <!-- Group Filter Bar -->
            <div class="panel" style="padding:1.25rem 1.75rem;">
                <form method="GET" action="comments.php" style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap;">
                    <label class="form-label" style="margin:0;">Filter by Project:</label>
                    <select name="project_id" class="form-control" style="max-width:320px;" onchange="this.form.submit()">
                        <option value="">All Projects (<?= count($comments) ?>)</option>
                        <?php foreach ($projectsList as $pItem): ?>
                            <option value="<?= $pItem['id'] ?>" <?= $filterProject === (int)$pItem['id'] ? 'selected' : '' ?>>
                                <?= e($pItem['title']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if ($filterProject): ?>
                        <a href="comments.php" class="btn btn-outline btn-sm">Clear Filter</a>
                    <?php endif; ?>
                </form>
            </div>

            <!-- Comments Table -->
            <div class="panel">
                <div class="panel-header">
                    <h2 class="panel-title">Comments Stream</h2>
                </div>

                <div class="data-table-wrap">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>Author</th>
                                <th>Project</th>
                                <th>Comment Text</th>
                                <th>Submitted</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($comments)): ?>
                                <tr>
                                    <td colspan="6" style="text-align:center;padding:2.5rem;color:var(--text-muted);">
                                        No comments found for this selection.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($comments as $c): ?>
                                    <tr style="<?= $c['status'] === 'pending' ? 'background:rgba(6,182,212,0.04);' : '' ?>">
                                        <td>
                                            <?php if ($c['status'] === 'approved'): ?>
                                                <span class="badge badge-success"><i class="fas fa-check"></i> Approved</span>
                                            <?php elseif ($c['status'] === 'pending'): ?>
                                                <span class="badge badge-warning"><i class="fas fa-clock"></i> Pending</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger"><i class="fas fa-times"></i> Rejected</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?= e($c['author_name']) ?></strong><br>
                                            <small style="color:var(--text-muted);"><?= e($c['author_email']) ?></small>
                                        </td>
                                        <td>
                                            <a href="../project.php?id=<?= $c['project_id'] ?>" target="_blank" style="color:var(--cyan);font-weight:600;font-size:0.85rem;">
                                                <?= e($c['project_title']) ?>
                                            </a>
                                        </td>
                                        <td style="max-width:380px;">
                                            <div style="font-size:0.9rem;color:#e5e7eb;line-height:1.5;">
                                                <?= nl2br(e($c['comment_text'])) ?>
                                            </div>
                                        </td>
                                        <td style="font-size:0.82rem;color:var(--text-muted);white-space:nowrap;">
                                            <?= date('M d, Y H:i', strtotime($c['created_at'])) ?>
                                        </td>
                                        <td style="white-space:nowrap;">
                                            <div style="display:flex;gap:0.4rem;">
                                                <?php if ($c['status'] !== 'approved'): ?>
                                                    <form method="POST" action="comments.php<?= $filterProject ? '?project_id='.$filterProject : '' ?>" style="display:inline;">
                                                        <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                        <input type="hidden" name="action" value="approve">
                                                        <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                                        <button type="submit" class="btn btn-primary btn-sm" title="Approve">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>

                                                <?php if ($c['status'] !== 'rejected'): ?>
                                                    <form method="POST" action="comments.php<?= $filterProject ? '?project_id='.$filterProject : '' ?>" style="display:inline;">
                                                        <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                        <input type="hidden" name="action" value="reject">
                                                        <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                                        <button type="submit" class="btn btn-outline btn-sm" title="Reject / Hide">
                                                            <i class="fas fa-eye-slash"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>

                                                <form method="POST" action="comments.php<?= $filterProject ? '?project_id='.$filterProject : '' ?>" onsubmit="return confirm('Delete this comment permanently?');" style="display:inline;">
                                                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?= $c['id'] ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
