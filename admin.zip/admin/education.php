<?php
/**
 * Administrator — Education Management (Full CRUD)
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();
$pdo = getDBConnection();

$actionMsg   = '';
$actionError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $actionError = 'Security token invalid. Please refresh.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'save') {
            $id              = !empty($_POST['id']) ? (int)$_POST['id'] : null;
            $degree          = trim($_POST['degree'] ?? '');
            $institution     = trim($_POST['institution'] ?? '');
            $location        = trim($_POST['location'] ?? 'Palakkad, Kerala');
            $completion_date = trim($_POST['completion_date'] ?? '');
            $score           = trim($_POST['score'] ?? '');
            $display_order   = (int)($_POST['display_order'] ?? 0);

            if (empty($degree) || empty($institution)) {
                $actionError = 'Degree and institution are required.';
            } else {
                try {
                    if ($id) {
                        $stmt = $pdo->prepare("
                            UPDATE education SET
                                degree = ?, institution = ?, location = ?,
                                completion_date = ?, score = ?, display_order = ?
                            WHERE id = ?
                        ");
                        $stmt->execute([$degree, $institution, $location, $completion_date, $score, $display_order, $id]);
                        $actionMsg = 'Education record updated successfully.';
                    } else {
                        $stmt = $pdo->prepare("
                            INSERT INTO education (degree, institution, location, completion_date, score, display_order)
                            VALUES (?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([$degree, $institution, $location, $completion_date, $score, $display_order]);
                        $actionMsg = 'New education record added.';
                    }
                } catch (Exception $e) {
                    $actionError = 'Database error: ' . $e->getMessage();
                }
            }
        } elseif ($action === 'delete') {
            $delId = (int)($_POST['id'] ?? 0);
            if ($delId > 0) {
                $pdo->prepare("DELETE FROM education WHERE id = ?")->execute([$delId]);
                $actionMsg = 'Education record removed.';
            }
        }
    }
}

$records = $pdo->query("SELECT * FROM education ORDER BY display_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);

$editRecord = null;
if (isset($_GET['edit'])) {
    $eId = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM education WHERE id = ? LIMIT 1");
    $stmt->execute([$eId]);
    $editRecord = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Education Management · Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
</head>
<body>
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <main class="admin-main">
        <header class="topbar">
            <h1 class="topbar-title">
                <i class="fas fa-graduation-cap" style="color:var(--accent);"></i>
                Education Management
            </h1>
            <a href="education.php#editor" class="btn btn-primary btn-sm">+ Add Education</a>
        </header>

        <div class="admin-content">
            <?php if (!empty($actionMsg)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?= e($actionMsg) ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($actionError)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?= e($actionError) ?>
                </div>
            <?php endif; ?>

            <!-- Editor Form Panel -->
            <div id="editor" class="panel">
                <div class="panel-header">
                    <span class="panel-title">
                        <i class="fas fa-<?= $editRecord ? 'edit' : 'plus-circle' ?>" style="color:var(--accent);margin-right:0.4rem;"></i>
                        <?= $editRecord ? 'Edit Education Record' : 'Add New Education Record' ?>
                    </span>
                    <?php if ($editRecord): ?>
                        <a href="education.php" class="btn btn-secondary btn-sm">Cancel Edit</a>
                    <?php endif; ?>
                </div>

                <form method="POST" action="education.php#editor">
                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                    <input type="hidden" name="action" value="save">
                    <?php if ($editRecord): ?>
                        <input type="hidden" name="id" value="<?= (int)$editRecord['id'] ?>">
                    <?php endif; ?>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="degree">Degree / Qualification *</label>
                            <input type="text" id="degree" name="degree" class="form-control" required
                                value="<?= e($editRecord['degree'] ?? '') ?>"
                                placeholder="B.Tech, Information Technology">
                        </div>
                        <div class="form-group">
                            <label for="institution">Institution Name *</label>
                            <input type="text" id="institution" name="institution" class="form-control" required
                                value="<?= e($editRecord['institution'] ?? '') ?>"
                                placeholder="Government Engineering College Sreekrishnapuram">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="location">Location</label>
                            <input type="text" id="location" name="location" class="form-control"
                                value="<?= e($editRecord['location'] ?? 'Palakkad, Kerala') ?>"
                                placeholder="Palakkad, Kerala">
                        </div>
                        <div class="form-group">
                            <label for="completion_date">Completion Year / Date</label>
                            <input type="text" id="completion_date" name="completion_date" class="form-control"
                                value="<?= e($editRecord['completion_date'] ?? '') ?>"
                                placeholder="Completed May 2026">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="score">Score / Grade / CGPA</label>
                            <input type="text" id="score" name="score" class="form-control"
                                value="<?= e($editRecord['score'] ?? '') ?>"
                                placeholder="CGPA: 8.43 or 97%">
                        </div>
                        <div class="form-group">
                            <label for="display_order">Display Order</label>
                            <input type="number" id="display_order" name="display_order" class="form-control" min="0"
                                value="<?= (int)($editRecord['display_order'] ?? 1) ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?= $editRecord ? 'Update Record' : 'Save Record' ?>
                    </button>
                </form>
            </div>

            <!-- Existing Records List -->
            <div class="panel">
                <div class="panel-header">
                    <span class="panel-title">Existing Education Records (<?= count($records) ?>)</span>
                </div>

                <?php if (empty($records)): ?>
                    <p style="color:var(--text-muted);">No records found.</p>
                <?php else: ?>
                    <div class="data-table-wrap">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th style="width:60px;">Order</th>
                                    <th>Degree / Qualification</th>
                                    <th>Institution</th>
                                    <th>Location</th>
                                    <th>Date</th>
                                    <th>Score</th>
                                    <th style="text-align:right;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($records as $r): ?>
                                    <tr>
                                        <td>
                                            <span style="display:inline-block;width:26px;height:26px;line-height:26px;text-align:center;border-radius:50%;background:var(--accent-soft);color:var(--accent);font-weight:700;font-size:0.8rem;">
                                                <?= (int)$r['display_order'] ?>
                                            </span>
                                        </td>
                                        <td style="font-weight:600;color:#fff;"><?= e($r['degree']) ?></td>
                                        <td style="color:var(--cyan);"><?= e($r['institution']) ?></td>
                                        <td><?= e($r['location'] ?? '—') ?></td>
                                        <td><?= e($r['completion_date'] ?? '—') ?></td>
                                        <td>
                                            <?php if (!empty($r['score'])): ?>
                                                <span class="badge" style="background:var(--warning-soft);color:var(--warning);">
                                                    <?= e($r['score']) ?>
                                                </span>
                                            <?php else: ?>
                                                —
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align:right;">
                                            <a href="education.php?edit=<?= (int)$r['id'] ?>#editor" class="btn btn-secondary btn-sm">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this education record?');">
                                                <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</body>
</html>
