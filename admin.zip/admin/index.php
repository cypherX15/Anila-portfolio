<?php
/**
 * Administrator Dashboard Overview
 * Compact, modern statistics and activity monitors.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();
$pdo = getDBConnection();

// Statistics
$totalProjects        = (int)$pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$restrictedProjects   = (int)$pdo->query("SELECT COUNT(*) FROM projects WHERE is_restricted = 1")->fetchColumn();

$totalAccessRequests  = (int)$pdo->query("SELECT COUNT(*) FROM project_access_requests")->fetchColumn();
$pendingAccess        = (int)$pdo->query("SELECT COUNT(*) FROM project_access_requests WHERE status = 'pending'")->fetchColumn();

$totalComments        = (int)$pdo->query("SELECT COUNT(*) FROM project_comments")->fetchColumn();
$pendingComments      = (int)$pdo->query("SELECT COUNT(*) FROM project_comments WHERE status = 'pending'")->fetchColumn();

$totalMessages        = (int)$pdo->query("SELECT COUNT(*) FROM contact_messages")->fetchColumn();
$unreadMessages       = (int)$pdo->query("SELECT COUNT(*) FROM contact_messages WHERE is_read = 0")->fetchColumn();

// Recent Activity Data
$recentPendingAccess = $pdo->query("
    SELECT r.*, p.title AS project_title
    FROM project_access_requests r
    JOIN projects p ON r.project_id = p.id
    WHERE r.status = 'pending'
    ORDER BY r.created_at DESC LIMIT 5
")->fetchAll();

$recentPendingComments = $pdo->query("
    SELECT c.*, p.title AS project_title
    FROM project_comments c
    JOIN projects p ON c.project_id = p.id
    WHERE c.status = 'pending'
    ORDER BY c.created_at DESC LIMIT 5
")->fetchAll();

$recentMessages = $pdo->query("
    SELECT * FROM contact_messages
    ORDER BY is_read ASC, created_at DESC LIMIT 5
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard · Anila S Portfolio</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
</head>
<body>
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <main class="admin-main">
        <header class="topbar">
            <h1 class="topbar-title">Dashboard Overview</h1>
            <div class="topbar-right">
                <span style="color:var(--text-muted);font-size:0.9rem;">
                    Logged in as <strong><?= e($_SESSION['admin_name'] ?? 'Admin') ?></strong>
                </span>
                <a href="../index.php" target="_blank" class="btn btn-outline btn-sm">
                    <i class="fas fa-external-link-alt"></i> View Public Site
                </a>
            </div>
        </header>

        <div class="admin-content">
            <!-- Metrics Summary Grid -->
            <div class="metrics-grid">
                <!-- Projects -->
                <div class="metric-card">
                    <div>
                        <div class="metric-label">Total Projects</div>
                        <div class="metric-number"><?= $totalProjects ?></div>
                        <span style="color:var(--text-muted);font-size:0.8rem;"><?= $restrictedProjects ?> restricted</span>
                    </div>
                    <span class="metric-icon" style="color:var(--accent);"><i class="fas fa-layer-group"></i></span>
                </div>

                <!-- Access Requests -->
                <div class="metric-card" style="<?= $pendingAccess > 0 ? 'border-color:var(--warning);' : '' ?>">
                    <div>
                        <div class="metric-label">Access Requests</div>
                        <div class="metric-number" style="<?= $pendingAccess > 0 ? 'color:var(--warning);' : '' ?>"><?= $pendingAccess ?> <span style="font-size:0.9rem;font-weight:400;color:var(--text-muted);">/ <?= $totalAccessRequests ?></span></div>
                        <a href="access_requests.php" style="color:var(--accent);font-size:0.8rem;">Review Requests &rarr;</a>
                    </div>
                    <span class="metric-icon" style="color:var(--warning);"><i class="fas fa-shield-alt"></i></span>
                </div>

                <!-- Project Comments -->
                <div class="metric-card" style="<?= $pendingComments > 0 ? 'border-color:var(--cyan);' : '' ?>">
                    <div>
                        <div class="metric-label">Project Comments</div>
                        <div class="metric-number" style="<?= $pendingComments > 0 ? 'color:var(--cyan);' : '' ?>"><?= $pendingComments ?> <span style="font-size:0.9rem;font-weight:400;color:var(--text-muted);">/ <?= $totalComments ?></span></div>
                        <a href="comments.php" style="color:var(--cyan);font-size:0.8rem;">Moderate Comments &rarr;</a>
                    </div>
                    <span class="metric-icon" style="color:var(--cyan);"><i class="fas fa-comments"></i></span>
                </div>

                <!-- Messages -->
                <div class="metric-card" style="<?= $unreadMessages > 0 ? 'border-color:var(--accent);' : '' ?>">
                    <div>
                        <div class="metric-label">Contact Messages</div>
                        <div class="metric-number" style="<?= $unreadMessages > 0 ? 'color:var(--accent);' : '' ?>"><?= $unreadMessages ?> <span style="font-size:0.9rem;font-weight:400;color:var(--text-muted);">unread</span></div>
                        <a href="messages.php" style="color:var(--accent);font-size:0.8rem;">Inbox (<?= $totalMessages ?>) &rarr;</a>
                    </div>
                    <span class="metric-icon" style="color:var(--accent);"><i class="fas fa-envelope"></i></span>
                </div>
            </div>

            <!-- Pending Access Requests Panel -->
            <?php if (!empty($recentPendingAccess)): ?>
                <div class="panel">
                    <div class="panel-header">
                        <h2 class="panel-title"><i class="fas fa-shield-alt" style="color:var(--warning);"></i> Pending Project Access Requests</h2>
                        <a href="access_requests.php" class="btn btn-outline btn-sm">View All &rarr;</a>
                    </div>
                    <div class="data-table-wrap">
                        <table class="data-table">
                            <thead>
                                <tr><th>Visitor</th><th>Project</th><th>Reason</th><th>Submitted</th><th>Actions</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentPendingAccess as $req): ?>
                                    <tr>
                                        <td><strong><?= e($req['visitor_name']) ?></strong><br><small style="color:var(--text-muted);"><?= e($req['visitor_email']) ?></small></td>
                                        <td><span class="badge badge-warning"><?= e($req['project_title']) ?></span></td>
                                        <td style="max-width:280px;font-size:0.85rem;color:#d1d5db;"><?= e(mb_strimwidth($req['reason'], 0, 75, '...')) ?></td>
                                        <td style="font-size:0.8rem;color:var(--text-muted);"><?= date('M d, H:i', strtotime($req['created_at'])) ?></td>
                                        <td>
                                            <div style="display:flex;gap:0.4rem;">
                                                <form method="POST" action="access_requests.php" style="display:inline;">
                                                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                    <input type="hidden" name="action" value="approve">
                                                    <input type="hidden" name="id" value="<?= $req['id'] ?>">
                                                    <button type="submit" class="btn btn-primary btn-sm">Approve</button>
                                                </form>
                                                <form method="POST" action="access_requests.php" style="display:inline;">
                                                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                    <input type="hidden" name="action" value="reject">
                                                    <input type="hidden" name="id" value="<?= $req['id'] ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Pending Project Comments Panel -->
            <?php if (!empty($recentPendingComments)): ?>
                <div class="panel">
                    <div class="panel-header">
                        <h2 class="panel-title"><i class="fas fa-comments" style="color:var(--cyan);"></i> Project Comments Awaiting Approval</h2>
                        <a href="comments.php" class="btn btn-outline btn-sm">Moderate All &rarr;</a>
                    </div>
                    <div class="data-table-wrap">
                        <table class="data-table">
                            <thead>
                                <tr><th>Author</th><th>Project</th><th>Comment</th><th>Date</th><th>Action</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentPendingComments as $com): ?>
                                    <tr>
                                        <td><strong><?= e($com['author_name']) ?></strong><br><small style="color:var(--text-muted);"><?= e($com['author_email']) ?></small></td>
                                        <td><span class="badge badge-cyan"><?= e($com['project_title']) ?></span></td>
                                        <td style="max-width:320px;font-size:0.85rem;color:#d1d5db;"><?= e(mb_strimwidth($com['comment_text'], 0, 90, '...')) ?></td>
                                        <td style="font-size:0.8rem;color:var(--text-muted);"><?= date('M d, H:i', strtotime($com['created_at'])) ?></td>
                                        <td>
                                            <form method="POST" action="comments.php" style="display:inline;">
                                                <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                <input type="hidden" name="action" value="approve">
                                                <input type="hidden" name="id" value="<?= $com['id'] ?>">
                                                <button type="submit" class="btn btn-primary btn-sm">Approve</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Recent Messages Panel -->
            <div class="panel">
                <div class="panel-header">
                    <h2 class="panel-title"><i class="fas fa-envelope"></i> Recent Contact Messages</h2>
                    <a href="messages.php" class="btn btn-outline btn-sm">View All &rarr;</a>
                </div>
                <div class="data-table-wrap">
                    <table class="data-table">
                        <thead>
                            <tr><th>Status</th><th>Sender</th><th>Subject</th><th>Received</th><th>Action</th></tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recentMessages)): ?>
                                <tr><td colspan="5" style="text-align:center;padding:2rem;color:var(--text-muted);">No messages received yet.</td></tr>
                            <?php else: ?>
                                <?php foreach ($recentMessages as $msg): ?>
                                    <tr>
                                        <td>
                                            <?= $msg['is_read'] ? '<span class="badge" style="background:#374151;color:#9ca3af;">Read</span>' : '<span class="badge badge-warning">New</span>' ?>
                                        </td>
                                        <td><strong><?= e($msg['name']) ?></strong><br><small style="color:var(--text-muted);"><?= e($msg['email']) ?></small></td>
                                        <td><?= e($msg['subject']) ?></td>
                                        <td style="font-size:0.8rem;color:var(--text-muted);"><?= date('M d, Y', strtotime($msg['created_at'])) ?></td>
                                        <td>
                                            <a href="messages.php" class="btn btn-outline btn-sm">Read Message</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
