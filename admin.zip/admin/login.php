<?php
/**
 * Administrator Secure Login Portal
 * Matches the updated `admins` table schema.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';

$error = '';

if (isAdminLoggedIn()) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Security session expired. Please refresh the page.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (empty($username) || empty($password)) {
            $error = 'Please enter both username/email and password.';
        } else {
            try {
                $pdo = getDBConnection();
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ? OR email = ? LIMIT 1");
                $stmt->execute([$username, $username]);
                $admin = $stmt->fetch();

                if ($admin && password_verify($password, $admin['password_hash'])) {
                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['admin_id']        = $admin['id'];
                    $_SESSION['admin_username']  = $admin['username'];
                    $_SESSION['admin_name']      = $admin['full_name'];

                    header('Location: index.php');
                    exit;
                } else {
                    $error = 'Invalid administrative credentials.';
                }
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal Login · Anila S Portfolio</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
    <style>
        .login-wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 2rem 1rem; }
        .login-card { max-width: 440px; width: 100%; background: rgba(18, 18, 40, 0.95); border: 1px solid rgba(139, 92, 246, 0.25); border-radius: 20px; padding: 2.75rem 2.25rem; box-shadow: 0 20px 50px rgba(0,0,0,0.6); position: relative; }
        .login-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #8b5cf6, #6366f1, #06b6d4); border-radius: 20px 20px 0 0; }
        .login-hint { background: rgba(139, 92, 246, 0.08); border: 1px solid rgba(139, 92, 246, 0.25); border-radius: 10px; padding: 0.85rem; font-size: 0.85rem; color: #c4b5fd; margin-bottom: 1.5rem; }
    </style>
</head>
<body>
    <div class="login-wrap">
        <div class="login-card">
            <div style="display:flex;align-items:center;gap:0.6rem;margin-bottom:0.4rem;">
                <span class="brand-badge" style="width:10px;height:10px;"></span>
                <h1 style="font-size:1.4rem;font-weight:700;color:#fff;margin:0;">Administrator Portal</h1>
            </div>
            <p style="color:var(--text-secondary);font-size:0.88rem;margin-bottom:1.5rem;">
                Sign in to manage projects, access requests, comments, and messages.
            </p>

            <div class="login-hint">
                <i class="fas fa-key"></i> <strong>Default Credentials:</strong><br>
                User: <code style="color:#fff;">admin</code> &nbsp;|&nbsp; Password: <code style="color:#fff;">admin123</code>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" style="padding:0.75rem 1rem;font-size:0.88rem;">
                    <span class="alert-icon"><i class="fas fa-exclamation-circle"></i></span>
                    <div><?= e($error) ?></div>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">

                <div class="form-group">
                    <label class="form-label" for="username">Username or Email</label>
                    <input type="text" id="username" name="username" class="form-control" required autofocus
                           value="<?= e($_POST['username'] ?? '') ?>">
                </div>

                <div class="form-group" style="margin-bottom:1.75rem;">
                    <label class="form-label" for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary btn-full">
                    <i class="fas fa-lock"></i> Authenticate
                </button>
            </form>

            <div style="margin-top:1.75rem;text-align:center;">
                <a href="../index.php" style="color:var(--text-muted);font-size:0.85rem;">
                    &larr; Return to Public Website
                </a>
            </div>
        </div>
    </div>
</body>
</html>
