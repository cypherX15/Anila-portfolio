<?php
/**
 * Administrator — Projects Management (Full CRUD)
 * Add, edit, delete, upload images/reports, configure access restrictions.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();
$pdo = getDBConnection();

$actionMsg   = '';
$actionError = '';

// Helper for secure file uploads
function handleUpload(string $fieldName, string $uploadDir, array $allowedExtensions, int $maxSizeMB = 10): ?string {
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($_FILES[$fieldName]['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException("Upload failed on field '$fieldName' with code " . $_FILES[$fieldName]['error']);
    }

    $file = $_FILES[$fieldName];
    $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, $allowedExtensions, true)) {
        throw new RuntimeException("Invalid file extension '.$ext'. Allowed: " . implode(', ', $allowedExtensions));
    }
    if ($file['size'] > $maxSizeMB * 1024 * 1024) {
        throw new RuntimeException("File exceeds maximum size of {$maxSizeMB}MB.");
    }

    $targetDir = __DIR__ . '/../uploads/' . $uploadDir . '/';
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $filename = uniqid('p_', true) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $targetDir . $filename)) {
        throw new RuntimeException("Failed to save uploaded file.");
    }
    return $filename;
}

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $actionError = 'Security token invalid. Please refresh.';
    } else {
        $action = $_POST['action'] ?? '';

        // 1. QUICK TOGGLE ACCESS FROM TABLE
        if ($action === 'toggle_access') {
            $tId = (int)($_POST['id'] ?? 0);
            if ($tId > 0) {
                $curr = $pdo->prepare("SELECT is_restricted, title FROM projects WHERE id = ?");
                $curr->execute([$tId]);
                $row = $curr->fetch();
                if ($row) {
                    $newVal = (int)$row['is_restricted'] ? 0 : 1;
                    $pdo->prepare("UPDATE projects SET is_restricted = ? WHERE id = ?")->execute([$newVal, $tId]);
                    $modeLabel = $newVal ? 'Restricted (Access Request Required)' : 'Public (Open Access)';
                    $actionMsg = "Access for '{$row['title']}' updated to {$modeLabel}.";
                }
            }
        }

        // 2. CREATE OR UPDATE PROJECT
        elseif ($action === 'save') {
            $id            = !empty($_POST['id']) ? (int)$_POST['id'] : null;
            $title         = trim($_POST['title'] ?? '');
            $short_tagline = trim($_POST['short_tagline'] ?? '');
            $category      = trim($_POST['category'] ?? 'Engineering');
            $technologies  = trim($_POST['technologies'] ?? '');
            $description   = trim($_POST['description'] ?? '');
            $overview      = trim($_POST['overview'] ?? '');
            $problem       = trim($_POST['problem_statement'] ?? '');
            $objectives    = trim($_POST['objectives'] ?? '');
            $implementation= trim($_POST['implementation_details'] ?? '');
            $github_url    = trim($_POST['github_url'] ?? '');
            $demo_url      = trim($_POST['demo_url'] ?? '');
            $video_url     = trim($_POST['video_url'] ?? '');
            $is_featured   = (isset($_POST['is_featured']) && (string)$_POST['is_featured'] === '1') ? 1 : 0;
            $is_restricted = (isset($_POST['is_restricted']) && (string)$_POST['is_restricted'] === '1') ? 1 : 0;
            $display_order = (int)($_POST['display_order'] ?? 0);

            if (empty($title) || empty($short_tagline) || empty($technologies)) {
                $actionError = 'Title, short tagline, and technologies are required.';
            } else {
                try {
                    $thumbnail  = handleUpload('thumbnail', 'thumbnails', ['jpg','jpeg','png','webp','gif','svg'], 8);
                    $report_pdf = handleUpload('report_pdf', 'reports', ['pdf'], 25);

                    if ($id) {
                        // Keep current files if none uploaded
                        $curStmt = $pdo->prepare("SELECT thumbnail, report_pdf FROM projects WHERE id = ?");
                        $curStmt->execute([$id]);
                        $cur = $curStmt->fetch();

                        $thumbnail  = $thumbnail  ?? ($cur['thumbnail'] ?? null);
                        $report_pdf = $report_pdf ?? ($cur['report_pdf'] ?? null);

                        $stmt = $pdo->prepare("
                            UPDATE projects SET
                                title = ?, short_tagline = ?, description = ?, overview = ?, problem_statement = ?,
                                objectives = ?, implementation_details = ?, technologies = ?, thumbnail = ?,
                                video_url = ?, report_pdf = ?, github_url = ?, demo_url = ?, category = ?,
                                is_featured = ?, is_restricted = ?, display_order = ?
                            WHERE id = ?
                        ");
                        $stmt->execute([
                            $title, $short_tagline, $description, $overview, $problem,
                            $objectives, $implementation, $technologies, $thumbnail,
                            $video_url, $report_pdf, $github_url, $demo_url, $category,
                            $is_featured, $is_restricted, $display_order, $id
                        ]);
                        $accessText = $is_restricted ? 'Restricted' : 'Public';
                        $actionMsg = "Project '{$title}' updated successfully (Access: {$accessText}).";
                    } else {
                        $stmt = $pdo->prepare("
                            INSERT INTO projects
                            (title, short_tagline, description, overview, problem_statement, objectives, implementation_details,
                             technologies, thumbnail, video_url, report_pdf, github_url, demo_url, category, is_featured, is_restricted, display_order)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([
                            $title, $short_tagline, $description, $overview, $problem, $objectives, $implementation,
                            $technologies, $thumbnail, $video_url, $report_pdf, $github_url, $demo_url, $category,
                            $is_featured, $is_restricted, $display_order
                        ]);
                        $id = (int)$pdo->lastInsertId();
                        $actionMsg = "New project '{$title}' created successfully.";
                    }

                    // Handle Screenshots Gallery Upload
                    if (!empty($_FILES['screenshots']['name'][0])) {
                        foreach ($_FILES['screenshots']['tmp_name'] as $idx => $tmp) {
                            if ($_FILES['screenshots']['error'][$idx] !== UPLOAD_ERR_OK) continue;
                            $name = $_FILES['screenshots']['name'][$idx];
                            $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                            if (!in_array($ext, ['jpg','jpeg','png','webp','gif','svg'], true)) continue;

                            $dir = __DIR__ . '/../uploads/screenshots/';
                            if (!is_dir($dir)) mkdir($dir, 0755, true);

                            $ssName = uniqid('ss_', true) . '.' . $ext;
                            if (move_uploaded_file($tmp, $dir . $ssName)) {
                                $insSs = $pdo->prepare("INSERT INTO project_resources (project_id, file_path, file_type, caption) VALUES (?, ?, 'screenshot', '')");
                                $insSs->execute([$id, $ssName]);
                            }
                        }
                    }

                } catch (Exception $e) {
                    $actionError = 'Error: ' . $e->getMessage();
                }
            }
        }

        // 3. DELETE PROJECT
        elseif ($action === 'delete') {
            $delId = (int)($_POST['id'] ?? 0);
            if ($delId > 0) {
                try {
                    $pdo->prepare("DELETE FROM projects WHERE id = ?")->execute([$delId]);
                    $actionMsg = 'Project deleted.';
                } catch (Exception $e) {
                    $actionError = 'Failed to delete project: ' . $e->getMessage();
                }
            }
        }

        // 4. DELETE SCREENSHOT (Handled safely outside main form)
        elseif ($action === 'delete_screenshot') {
            $ssId = (int)($_POST['ss_id'] ?? 0);
            if ($ssId > 0) {
                $ss = $pdo->prepare("SELECT file_path, project_id FROM project_resources WHERE id = ?");
                $ss->execute([$ssId]);
                $row = $ss->fetch();
                if ($row) {
                    $fp = __DIR__ . '/../uploads/screenshots/' . $row['file_path'];
                    if (file_exists($fp)) @unlink($fp);
                    $pdo->prepare("DELETE FROM project_resources WHERE id = ?")->execute([$ssId]);
                    $actionMsg = 'Screenshot removed.';
                    $_GET['edit'] = $row['project_id']; // stay in editor
                }
            }
        }
    }
}

// Fetch all projects
$projects = $pdo->query("SELECT * FROM projects ORDER BY display_order ASC, id DESC")->fetchAll(PDO::FETCH_ASSOC);

// Edit Project Load
$editProject = null;
$editResources = [];
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $eStmt  = $pdo->prepare("SELECT * FROM projects WHERE id = ? LIMIT 1");
    $eStmt->execute([$editId]);
    $editProject = $eStmt->fetch(PDO::FETCH_ASSOC);

    if ($editProject) {
        $rStmt = $pdo->prepare("SELECT * FROM project_resources WHERE project_id = ? ORDER BY display_order ASC, id ASC");
        $rStmt->execute([$editId]);
        $editResources = $rStmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Projects · Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
    <style>
        .thumb-preview-box { width: 140px; height: 85px; border-radius: 8px; object-fit: cover; border: 1px solid var(--border-color); margin-top: 0.5rem; display: block; }
        .ss-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 0.75rem; margin-top: 0.75rem; }
        .ss-item { position: relative; border-radius: 6px; overflow: hidden; border: 1px solid var(--border-color); }
        .ss-item img { width: 100%; aspect-ratio: 16/10; object-fit: cover; display: block; }
        .ss-del-btn { position: absolute; top: 4px; right: 4px; background: rgba(239,68,68,0.9); color: #fff; border: none; border-radius: 50%; width: 22px; height: 22px; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; font-weight: bold; }
        .ss-del-btn:hover { background: #dc2626; }
        .toggle-btn { background: none; border: none; cursor: pointer; padding: 0.25rem 0.65rem; border-radius: 999px; font-size: 0.78rem; font-weight: 700; display: inline-flex; align-items: center; gap: 0.35rem; transition: all 0.2s; font-family: inherit; }
        .toggle-btn:hover { transform: scale(1.04); }
    </style>
</head>
<body>
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <main class="admin-main">
        <header class="topbar">
            <h1 class="topbar-title">
                <i class="fas fa-layer-group" style="color:var(--accent);"></i>
                Projects Management
            </h1>
            <a href="projects.php#editor" class="btn btn-primary btn-sm">+ Add Project</a>
        </header>

        <div class="admin-content">
            <?php if (!empty($actionMsg)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?= e($actionMsg) ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($actionError)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?= e($actionError) ?>
                </div>
            <?php endif; ?>

            <!-- Project Form Editor -->
            <div id="editor" class="panel">
                <div class="panel-header">
                    <h2 class="panel-title">
                        <i class="fas fa-<?= $editProject ? 'edit' : 'plus-circle' ?>" style="color:var(--accent);margin-right:0.4rem;"></i>
                        <?= $editProject ? 'Edit Project: ' . e($editProject['title']) : 'Create New Project' ?>
                    </h2>
                    <?php if ($editProject): ?>
                        <a href="projects.php" class="btn btn-secondary btn-sm">Cancel Edit</a>
                    <?php endif; ?>
                </div>

                <form id="mainProjectForm" method="POST" action="projects.php#editor" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                    <input type="hidden" name="action" value="save">
                    <?php if ($editProject): ?>
                        <input type="hidden" name="id" value="<?= (int)$editProject['id'] ?>">
                    <?php endif; ?>

                    <div class="form-tabs">
                        <button type="button" class="form-tab-btn active" data-tab="tab-core">Core Information</button>
                        <button type="button" class="form-tab-btn" data-tab="tab-specs">Technical Details</button>
                        <button type="button" class="form-tab-btn" data-tab="tab-media">Media &amp; Files</button>
                        <button type="button" class="form-tab-btn" data-tab="tab-access">Access Settings</button>
                    </div>

                    <!-- Pane 1: Core -->
                    <div class="form-pane active" id="tab-core">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Project Title *</label>
                                <input type="text" name="title" class="form-control" required
                                       value="<?= e($editProject['title'] ?? '') ?>" placeholder="e.g. Text-Based PDF Compression Algorithm">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Category</label>
                                <input type="text" name="category" class="form-control"
                                       value="<?= e($editProject['category'] ?? 'Engineering') ?>" placeholder="e.g. Compression &amp; Web">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Short Tagline (Shown on Card) *</label>
                            <input type="text" name="short_tagline" class="form-control" required
                                   value="<?= e($editProject['short_tagline'] ?? '') ?>" placeholder="e.g. High-efficiency custom compressor combining MessagePack and LZMA...">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Technologies (comma separated) *</label>
                            <input type="text" name="technologies" class="form-control" required
                                   value="<?= e($editProject['technologies'] ?? '') ?>" placeholder="e.g. Python, LZMA, MessagePack, PyQt, Flask">
                        </div>

                        <div class="form-group">
                            <label class="form-label">General Description</label>
                            <textarea name="description" class="form-control" rows="3"><?= e($editProject['description'] ?? '') ?></textarea>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">GitHub Repository URL</label>
                                <input type="url" name="github_url" class="form-control"
                                       value="<?= e($editProject['github_url'] ?? '') ?>" placeholder="https://github.com/...">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Live Demo URL</label>
                                <input type="text" name="demo_url" class="form-control"
                                       value="<?= e($editProject['demo_url'] ?? '') ?>" placeholder="https://...">
                            </div>
                        </div>
                    </div>

                    <!-- Pane 2: Specs -->
                    <div class="form-pane" id="tab-specs">
                        <div class="form-group">
                            <label class="form-label">Project Overview</label>
                            <textarea name="overview" class="form-control" rows="4" placeholder="Detailed architectural and functional overview..."><?= e($editProject['overview'] ?? '') ?></textarea>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Problem Statement</label>
                            <textarea name="problem_statement" class="form-control" rows="3" placeholder="What challenge does this project address?"><?= e($editProject['problem_statement'] ?? '') ?></textarea>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Objectives (one per line)</label>
                            <textarea name="objectives" class="form-control" rows="4" placeholder="List key objectives, one per line..."><?= e($editProject['objectives'] ?? '') ?></textarea>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Implementation Details</label>
                            <textarea name="implementation_details" class="form-control" rows="4" placeholder="Algorithmic pipeline, frameworks, protocols, and workflows..."><?= e($editProject['implementation_details'] ?? '') ?></textarea>
                        </div>
                    </div>

                    <!-- Pane 3: Media -->
                    <div class="form-pane" id="tab-media">
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Project Thumbnail (Card &amp; Header Banner)</label>
                                <input type="file" name="thumbnail" class="form-control" accept="image/*,.svg">
                                <?php if (!empty($editProject['thumbnail'])): ?>
                                    <img src="../uploads/thumbnails/<?= e($editProject['thumbnail']) ?>" class="thumb-preview-box" alt="Thumbnail">
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Project Report (PDF Document)</label>
                                <input type="file" name="report_pdf" class="form-control" accept=".pdf">
                                <?php if (!empty($editProject['report_pdf'])): ?>
                                    <small style="color:var(--accent);display:block;margin-top:0.4rem;">
                                        <i class="fas fa-file-pdf"></i> Current: <?= e($editProject['report_pdf']) ?>
                                    </small>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Demonstration Video URL (YouTube or Direct Embed)</label>
                            <input type="text" name="video_url" class="form-control"
                                   value="<?= e($editProject['video_url'] ?? '') ?>" placeholder="https://youtube.com/watch?v=...">
                        </div>

                        <div class="form-group">
                            <label class="form-label">Upload Additional Screenshots (Select Multiple)</label>
                            <input type="file" name="screenshots[]" class="form-control" accept="image/*,.svg" multiple>
                        </div>

                        <?php if (!empty($editResources)): ?>
                            <div style="margin-top:1.25rem;">
                                <label class="form-label">Existing Screenshots Gallery (<?= count($editResources) ?>)</label>
                                <div class="ss-grid">
                                    <?php foreach ($editResources as $res): ?>
                                        <div class="ss-item">
                                            <img src="../uploads/screenshots/<?= e($res['file_path']) ?>" alt="Screenshot">
                                            <!-- Button calls JS function; NO nested form -->
                                            <button type="button" class="ss-del-btn" onclick="confirmDeleteScreenshot(<?= (int)$res['id'] ?>)" title="Remove screenshot">&times;</button>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Pane 4: Access Settings -->
                    <div class="form-pane" id="tab-access">
                        <div class="form-group">
                            <label class="form-label">Display Order</label>
                            <input type="number" name="display_order" class="form-control" style="max-width:180px;"
                                   value="<?= (int)($editProject['display_order'] ?? 0) ?>">
                        </div>

                        <!-- Explicit Radio Selector for Access Level: always sends exact 0 or 1 -->
                        <div class="form-group" style="margin-top:1.5rem;">
                            <label class="form-label" style="font-size:0.9rem;font-weight:700;color:#fff;">Project Access Permission</label>
                            <p style="font-size:0.82rem;color:var(--text-muted);margin-bottom:0.75rem;">
                                Choose whether visitors can freely inspect project materials or must request authorization.
                            </p>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;">
                                <label style="display:flex;align-items:flex-start;gap:0.85rem;padding:1.25rem;background:var(--bg-dark);border:2px solid <?= empty($editProject['is_restricted']) ? 'var(--success)' : 'var(--border-subtle)' ?>;border-radius:10px;cursor:pointer;">
                                    <input type="radio" name="is_restricted" value="0" <?= empty($editProject['is_restricted']) ? 'checked' : '' ?> style="margin-top:4px;">
                                    <div>
                                        <div style="font-weight:700;font-size:1rem;color:var(--success);display:flex;align-items:center;gap:0.4rem;">
                                            <i class="fas fa-globe"></i> Public Access
                                        </div>
                                        <div style="font-size:0.82rem;color:var(--text-muted);margin-top:0.3rem;line-height:1.45;">
                                            Documentation, reports, demo video, and code links are immediately accessible to anyone.
                                        </div>
                                    </div>
                                </label>

                                <label style="display:flex;align-items:flex-start;gap:0.85rem;padding:1.25rem;background:var(--bg-dark);border:2px solid <?= !empty($editProject['is_restricted']) ? 'var(--danger)' : 'var(--border-subtle)' ?>;border-radius:10px;cursor:pointer;">
                                    <input type="radio" name="is_restricted" value="1" <?= !empty($editProject['is_restricted']) ? 'checked' : '' ?> style="margin-top:4px;">
                                    <div>
                                        <div style="font-weight:700;font-size:1rem;color:var(--danger);display:flex;align-items:center;gap:0.4rem;">
                                            <i class="fas fa-lock"></i> Restricted Access
                                        </div>
                                        <div style="font-size:0.82rem;color:var(--text-muted);margin-top:0.3rem;line-height:1.45;">
                                            Materials are protected. Visitors must submit an access request and be approved by you.
                                        </div>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <!-- Featured Showcase -->
                        <div class="form-group" style="margin-top:1.5rem;">
                            <label class="form-label" style="font-size:0.9rem;font-weight:700;color:#fff;">Homepage Visibility</label>
                            <label style="display:flex;align-items:flex-start;gap:0.75rem;padding:1rem;background:var(--bg-dark);border:1px solid var(--border-subtle);border-radius:8px;cursor:pointer;max-width:500px;">
                                <input type="checkbox" name="is_featured" value="1"
                                       <?= (!isset($editProject) || !empty($editProject['is_featured'])) ? 'checked' : '' ?> style="margin-top:4px;">
                                <div>
                                    <div style="font-weight:600;font-size:0.95rem;color:#fff;">Featured Showcase</div>
                                    <div style="font-size:0.8rem;color:var(--text-muted);">Displays prominently on the portfolio homepage project grid.</div>
                                </div>
                            </label>
                        </div>
                    </div>

                    <div style="margin-top:2rem;padding-top:1.5rem;border-top:1px solid var(--border-color);display:flex;gap:1rem;align-items:center;">
                        <button type="submit" class="btn btn-primary" style="font-size:1rem;padding:0.75rem 2rem;">
                            <i class="fas fa-save"></i> <?= $editProject ? 'Save Project Changes' : 'Create Project' ?>
                        </button>
                        <?php if ($editProject): ?>
                            <span style="font-size:0.85rem;color:var(--text-muted);">
                                Currently: <strong><?= !empty($editProject['is_restricted']) ? 'Restricted' : 'Public' ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- Standalone Delete Screenshot Form (Outside the main form) -->
            <form id="standaloneDeleteScreenshotForm" method="POST" action="projects.php#editor" style="display:none;">
                <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                <input type="hidden" name="action" value="delete_screenshot">
                <input type="hidden" name="ss_id" id="standaloneSsId" value="0">
            </form>

            <!-- Existing Projects List -->
            <div class="panel">
                <div class="panel-header">
                    <h2 class="panel-title">All Projects (<?= count($projects) ?>)</h2>
                    <span style="font-size:0.82rem;color:var(--text-muted);">Tip: Click on the Access badge to toggle Public / Restricted immediately</span>
                </div>
                <div class="data-table-wrap">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Preview</th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Access (Click to Toggle)</th>
                                <th>Featured</th>
                                <th style="text-align:right;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($projects as $p): ?>
                                <tr>
                                    <td>
                                        <?php if (!empty($p['thumbnail'])): ?>
                                            <img src="../uploads/thumbnails/<?= e($p['thumbnail']) ?>"
                                                 style="width:65px;height:42px;object-fit:cover;border-radius:6px;border:1px solid var(--border-color);" alt="">
                                        <?php else: ?>
                                            <div style="width:65px;height:42px;background:var(--bg-surface);border-radius:6px;display:flex;align-items:center;justify-content:center;color:var(--text-muted);">
                                                <i class="fas fa-code"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong style="color:#fff;"><?= e($p['title']) ?></strong>
                                    </td>
                                    <td><span class="badge badge-warning"><?= e($p['category']) ?></span></td>
                                    <td>
                                        <!-- Quick 1-click access toggle form -->
                                        <form method="POST" action="projects.php" style="display:inline;" onsubmit="return confirm('Toggle access mode for <?= addslashes(e($p['title'])) ?>?');">
                                            <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                            <input type="hidden" name="action" value="toggle_access">
                                            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                                            <?php if ($p['is_restricted']): ?>
                                                <button type="submit" class="toggle-btn" style="background:rgba(239,68,68,0.2);color:#fca5a5;border:1px solid rgba(239,68,68,0.4);" title="Currently Restricted. Click to change to Public.">
                                                    <i class="fas fa-lock"></i> Restricted
                                                </button>
                                            <?php else: ?>
                                                <button type="submit" class="toggle-btn" style="background:rgba(16,185,129,0.2);color:#6ee7b7;border:1px solid rgba(16,185,129,0.4);" title="Currently Public. Click to change to Restricted.">
                                                    <i class="fas fa-globe"></i> Public
                                                </button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                    <td>
                                        <?= !empty($p['is_featured']) ? '<span class="badge badge-success">Yes</span>' : '<span class="badge" style="background:#374151;">No</span>' ?>
                                    </td>
                                    <td style="text-align:right;">
                                        <div style="display:inline-flex;gap:0.4rem;">
                                            <a href="../project.php?id=<?= $p['id'] ?>" target="_blank" class="btn btn-secondary btn-sm" title="View Public Page">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="projects.php?edit=<?= $p['id'] ?>#editor" class="btn btn-secondary btn-sm">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <form method="POST" action="projects.php" onsubmit="return confirm('Delete this project permanently?');" style="display:inline;">
                                                <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?= $p['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete Project"><i class="fas fa-trash"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script>
    // Tab Switching
    document.querySelectorAll('.form-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.form-tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.form-pane').forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            const target = document.getElementById(btn.dataset.tab);
            if (target) target.classList.add('active');
        });
    });

    // Delete screenshot without form nesting
    function confirmDeleteScreenshot(id) {
        if (confirm('Permanently remove this screenshot?')) {
            document.getElementById('standaloneSsId').value = id;
            document.getElementById('standaloneDeleteScreenshotForm').submit();
        }
    }
    </script>
</body>
</html>
