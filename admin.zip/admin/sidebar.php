<?php
/**
 * Admin Sidebar Navigation Component
 */
$currentPage = basename($_SERVER['PHP_SELF']);

// Live pending counters
try {
    $pdo = getDBConnection();
    $pendingAccessCount   = (int)$pdo->query("SELECT COUNT(*) FROM project_access_requests WHERE status = 'pending'")->fetchColumn();
    $pendingCommentsCount = (int)$pdo->query("SELECT COUNT(*) FROM project_comments WHERE status = 'pending'")->fetchColumn();
    $unreadMsgCount       = (int)$pdo->query("SELECT COUNT(*) FROM contact_messages WHERE is_read = 0")->fetchColumn();
} catch (Exception $e) {
    $pendingAccessCount   = 0;
    $pendingCommentsCount = 0;
    $unreadMsgCount       = 0;
}
?>
<aside class="sidebar">
    <div class="sidebar-brand">
        <span class="brand-dot"></span>
        <span>Anila S &bull; Control</span>
    </div>

    <ul class="sidebar-menu">

        <!-- Dashboard -->
        <li>
            <a href="index.php" class="sidebar-link <?= $currentPage === 'index.php' ? 'active' : '' ?>">
                <i class="fas fa-chart-pie" style="width:20px;"></i> Dashboard
            </a>
        </li>

        <!-- ── CONTENT MANAGEMENT ── -->
        <li class="sidebar-section-label">Content</li>

        <li>
            <a href="profile.php" class="sidebar-link <?= $currentPage === 'profile.php' ? 'active' : '' ?>">
                <i class="fas fa-user-circle" style="width:20px;"></i> Profile &amp; About
            </a>
        </li>
        <li>
            <a href="education.php" class="sidebar-link <?= $currentPage === 'education.php' ? 'active' : '' ?>">
                <i class="fas fa-graduation-cap" style="width:20px;"></i> Education
            </a>
        </li>
        <li>
            <a href="certifications.php" class="sidebar-link <?= $currentPage === 'certifications.php' ? 'active' : '' ?>">
                <i class="fas fa-award" style="width:20px;"></i> Certs &amp; Achievements
            </a>
        </li>
        <li>
            <a href="skills.php" class="sidebar-link <?= $currentPage === 'skills.php' ? 'active' : '' ?>">
                <i class="fas fa-code" style="width:20px;"></i> Technical Skills
            </a>
        </li>
        <li>
            <a href="projects.php" class="sidebar-link <?= $currentPage === 'projects.php' ? 'active' : '' ?>">
                <i class="fas fa-layer-group" style="width:20px;"></i> Projects
            </a>
        </li>

        <!-- ── INTERACTIONS ── -->
        <li class="sidebar-section-label">Interactions</li>

        <li>
            <a href="access_requests.php" class="sidebar-link <?= $currentPage === 'access_requests.php' ? 'active' : '' ?>">
                <i class="fas fa-shield-alt" style="width:20px;"></i> Access Requests
                <?php if ($pendingAccessCount > 0): ?>
                    <span class="sidebar-badge badge-warning"><?= $pendingAccessCount ?></span>
                <?php endif; ?>
            </a>
        </li>
        <li>
            <a href="comments.php" class="sidebar-link <?= $currentPage === 'comments.php' ? 'active' : '' ?>">
                <i class="fas fa-comments" style="width:20px;"></i> Project Comments
                <?php if ($pendingCommentsCount > 0): ?>
                    <span class="sidebar-badge badge-cyan"><?= $pendingCommentsCount ?></span>
                <?php endif; ?>
            </a>
        </li>
        <li>
            <a href="messages.php" class="sidebar-link <?= $currentPage === 'messages.php' ? 'active' : '' ?>">
                <i class="fas fa-envelope" style="width:20px;"></i> Contact Messages
                <?php if ($unreadMsgCount > 0): ?>
                    <span class="sidebar-badge badge-success"><?= $unreadMsgCount ?></span>
                <?php endif; ?>
            </a>
        </li>

    </ul>

    <div class="sidebar-footer">
        <a href="../index.php" target="_blank" class="sidebar-link" style="color:var(--cyan);">
            <i class="fas fa-external-link-alt" style="width:20px;"></i> View Website
        </a>
        <a href="logout.php" class="sidebar-link" style="color:var(--danger);">
            <i class="fas fa-sign-out-alt" style="width:20px;"></i> Sign Out
        </a>
    </div>
</aside>
