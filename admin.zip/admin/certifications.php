<?php
/**
 * Administrator — Certifications, Achievements & Sports Management (Full CRUD)
 * Supports file uploads for certificates and supporting documents (PDF / Images)
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();
$pdo = getDBConnection();

$actionMsg   = '';
$actionError = '';

$typeLabels = [
    'certification' => ['label' => 'Certification', 'icon' => 'fa-certificate', 'color' => 'var(--accent)', 'bg' => 'var(--accent-soft)'],
    'achievement'   => ['label' => 'Achievement',   'icon' => 'fa-trophy',      'color' => 'var(--warning)', 'bg' => 'var(--warning-soft)'],
    'sports'        => ['label' => 'Sports & Extracurricular', 'icon' => 'fa-running', 'color' => 'var(--cyan)', 'bg' => 'rgba(6,182,212,0.15)'],
];

// File upload helper
function handleCertDocumentUpload(string $fieldName = 'document_file'): ?string {
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($_FILES[$fieldName]['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException("Upload failed with error code " . $_FILES[$fieldName]['error']);
    }

    $file = $_FILES[$fieldName];
    $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['pdf', 'jpg', 'jpeg', 'png', 'webp'];

    if (!in_array($ext, $allowed, true)) {
        throw new RuntimeException("Invalid file type (." . $ext . "). Allowed: PDF, JPG, PNG, WEBP.");
    }
    if ($file['size'] > 12 * 1024 * 1024) {
        throw new RuntimeException("File size exceeds 12MB limit.");
    }

    $dir = __DIR__ . '/../uploads/certificates/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $filename = 'cert_' . uniqid('', true) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . $filename)) {
        throw new RuntimeException("Could not store uploaded document.");
    }
    return $filename;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $actionError = 'Security token invalid. Please refresh.';
    } else {
        $action = $_POST['action'] ?? '';

        // SAVE (ADD OR UPDATE)
        if ($action === 'save') {
            $id            = !empty($_POST['id']) ? (int)$_POST['id'] : null;
            $type          = trim($_POST['type'] ?? 'certification');
            $title         = trim($_POST['title'] ?? '');
            $issuer_org    = trim($_POST['issuer_org'] ?? '');
            $date_text     = trim($_POST['date_text'] ?? '');
            $description   = trim($_POST['description'] ?? '');
            $display_order = (int)($_POST['display_order'] ?? 0);

            if (!in_array($type, ['certification','achievement','sports'], true)) {
                $type = 'certification';
            }

            if (empty($title)) {
                $actionError = 'Title is required.';
            } else {
                try {
                    $newDoc = handleCertDocumentUpload('document_file');

                    if ($id) {
                        $curStmt = $pdo->prepare("SELECT document_file FROM certifications_achievements WHERE id = ?");
                        $curStmt->execute([$id]);
                        $curRow = $curStmt->fetch();
                        $docFile = $newDoc ?? ($curRow['document_file'] ?? null);

                        $stmt = $pdo->prepare("
                            UPDATE certifications_achievements SET
                                type = ?, title = ?, issuer_org = ?,
                                date_text = ?, description = ?, document_file = ?, display_order = ?
                            WHERE id = ?
                        ");
                        $stmt->execute([$type, $title, $issuer_org, $date_text, $description, $docFile, $display_order, $id]);
                        $actionMsg = 'Record updated successfully.';
                    } else {
                        $stmt = $pdo->prepare("
                            INSERT INTO certifications_achievements (type, title, issuer_org, date_text, description, document_file, display_order)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([$type, $title, $issuer_org, $date_text, $description, $newDoc, $display_order]);
                        $actionMsg = 'New record and supporting document added successfully.';
                    }
                } catch (Exception $e) {
                    $actionError = 'Error: ' . $e->getMessage();
                }
            }
        }

        // REMOVE DOCUMENT ONLY
        elseif ($action === 'remove_document') {
            $rId = (int)($_POST['id'] ?? 0);
            if ($rId > 0) {
                $stmt = $pdo->prepare("SELECT document_file FROM certifications_achievements WHERE id = ?");
                $stmt->execute([$rId]);
                $doc = $stmt->fetchColumn();
                if ($doc) {
                    $path = __DIR__ . '/../uploads/certificates/' . $doc;
                    if (file_exists($path)) @unlink($path);
                    $pdo->prepare("UPDATE certifications_achievements SET document_file = NULL WHERE id = ?")->execute([$rId]);
                    $actionMsg = 'Supporting document removed.';
                    $_GET['edit'] = $rId;
                }
            }
        }

        // DELETE ENTIRE RECORD
        elseif ($action === 'delete') {
            $delId = (int)($_POST['id'] ?? 0);
            if ($delId > 0) {
                $stmt = $pdo->prepare("SELECT document_file FROM certifications_achievements WHERE id = ?");
                $stmt->execute([$delId]);
                $doc = $stmt->fetchColumn();
                if ($doc) {
                    $path = __DIR__ . '/../uploads/certificates/' . $doc;
                    if (file_exists($path)) @unlink($path);
                }
                $pdo->prepare("DELETE FROM certifications_achievements WHERE id = ?")->execute([$delId]);
                $actionMsg = 'Record deleted.';
            }
        }
    }
}

// Edit Mode
$editRecord = null;
if (isset($_GET['edit'])) {
    $eId = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM certifications_achievements WHERE id = ? LIMIT 1");
    $stmt->execute([$eId]);
    $editRecord = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Filter View
$filterType = $_GET['filter'] ?? '';
if ($filterType && in_array($filterType, ['certification','achievement','sports'], true)) {
    $stmt = $pdo->prepare("SELECT * FROM certifications_achievements WHERE type = ? ORDER BY display_order ASC, id ASC");
    $stmt->execute([$filterType]);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $records = $pdo->query("SELECT * FROM certifications_achievements ORDER BY display_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);
}

// Stats
$stats = $pdo->query("SELECT type, COUNT(*) as cnt FROM certifications_achievements GROUP BY type")->fetchAll(PDO::FETCH_KEY_PAIR);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certifications &amp; Achievements · Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
</head>
<body>
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <main class="admin-main">
        <header class="topbar">
            <h1 class="topbar-title">
                <i class="fas fa-award" style="color:var(--warning);"></i>
                Certifications, Achievements &amp; Sports
            </h1>
            <a href="certifications.php#editor" class="btn btn-primary btn-sm">+ Add Record</a>
        </header>

        <div class="admin-content">
            <?php if (!empty($actionMsg)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?= e($actionMsg) ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($actionError)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?= e($actionError) ?>
                </div>
            <?php endif; ?>

            <!-- Metrics Overview -->
            <div class="metrics-grid" style="margin-bottom:1.75rem;">
                <div class="metric-card">
                    <div>
                        <div class="metric-number"><?= (int)($stats['certification'] ?? 0) ?></div>
                        <div class="metric-label">Certifications</div>
                    </div>
                    <i class="fas fa-certificate metric-icon" style="color:var(--accent);"></i>
                </div>
                <div class="metric-card">
                    <div>
                        <div class="metric-number"><?= (int)($stats['achievement'] ?? 0) ?></div>
                        <div class="metric-label">Achievements</div>
                    </div>
                    <i class="fas fa-trophy metric-icon" style="color:var(--warning);"></i>
                </div>
                <div class="metric-card">
                    <div>
                        <div class="metric-number"><?= (int)($stats['sports'] ?? 0) ?></div>
                        <div class="metric-label">Sports &amp; Extracurriculars</div>
                    </div>
                    <i class="fas fa-running metric-icon" style="color:var(--cyan);"></i>
                </div>
            </div>

            <!-- Editor Form Panel -->
            <div id="editor" class="panel">
                <div class="panel-header">
                    <span class="panel-title">
                        <i class="fas fa-<?= $editRecord ? 'edit' : 'plus-circle' ?>" style="color:var(--accent);margin-right:0.4rem;"></i>
                        <?= $editRecord ? 'Edit Record: ' . e($editRecord['title']) : 'Add New Record' ?>
                    </span>
                    <?php if ($editRecord): ?>
                        <a href="certifications.php" class="btn btn-secondary btn-sm">Cancel Edit</a>
                    <?php endif; ?>
                </div>

                <form method="POST" action="certifications.php#editor" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                    <input type="hidden" name="action" value="save">
                    <?php if ($editRecord): ?>
                        <input type="hidden" name="id" value="<?= (int)$editRecord['id'] ?>">
                    <?php endif; ?>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="type">Record Category *</label>
                            <select id="type" name="type" class="form-control" required>
                                <?php $selType = $editRecord['type'] ?? 'certification'; ?>
                                <option value="certification" <?= $selType === 'certification' ? 'selected' : '' ?>>Certification</option>
                                <option value="achievement" <?= $selType === 'achievement' ? 'selected' : '' ?>>Academic / Community Achievement</option>
                                <option value="sports" <?= $selType === 'sports' ? 'selected' : '' ?>>Sports &amp; Extracurricular Activities</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="title">Title *</label>
                            <input type="text" id="title" name="title" class="form-control" required
                                value="<?= e($editRecord['title'] ?? '') ?>"
                                placeholder="e.g. Elite plus Silver in NPTEL Ethical Hacking / KTU Kho-Kho Team">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="issuer_org">Issuer / Organizing Body</label>
                            <input type="text" id="issuer_org" name="issuer_org" class="form-control"
                                value="<?= e($editRecord['issuer_org'] ?? '') ?>"
                                placeholder="NPTEL, KTU, NSS, etc.">
                        </div>
                        <div class="form-group">
                            <label for="date_text">Date / Period</label>
                            <input type="text" id="date_text" name="date_text" class="form-control"
                                value="<?= e($editRecord['date_text'] ?? '') ?>"
                                placeholder="August 2024 / 2022 - Present">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="description">Short Description</label>
                        <textarea id="description" name="description" class="form-control" rows="2"
                            placeholder="Briefly describe the key milestone, responsibilities, or skills validated."><?= e($editRecord['description'] ?? '') ?></textarea>
                    </div>

                    <!-- Supporting Document Upload Section (NEW) -->
                    <div class="form-group" style="padding:1.25rem;background:var(--bg-dark);border:1px solid var(--border-subtle);border-radius:10px;">
                        <label for="document_file" style="color:#fff;font-size:0.9rem;margin-bottom:0.5rem;display:flex;align-items:center;gap:0.4rem;">
                            <i class="fas fa-file-upload" style="color:var(--cyan);"></i>
                            Supporting Document / Certificate File (PDF, PNG, JPG)
                        </label>

                        <?php if (!empty($editRecord['document_file'])): ?>
                            <div style="display:flex;align-items:center;gap:0.75rem;padding:0.75rem 1rem;background:var(--bg-panel);border:1px solid var(--border-color);border-radius:8px;margin-bottom:0.75rem;">
                                <i class="fas fa-file-pdf" style="color:var(--danger);font-size:1.1rem;"></i>
                                <span style="font-size:0.88rem;color:#cbd5e1;">Attached: <strong><?= e($editRecord['document_file']) ?></strong></span>
                                <a href="../uploads/certificates/<?= e($editRecord['document_file']) ?>" target="_blank" class="btn btn-secondary btn-sm" style="margin-left:auto;">
                                    <i class="fas fa-eye"></i> View File
                                </a>
                                <button type="button" class="btn btn-danger btn-sm" onclick="document.getElementById('removeDocForm').submit();" title="Remove this document">
                                    <i class="fas fa-times"></i> Remove
                                </button>
                            </div>
                        <?php endif; ?>

                        <input type="file" id="document_file" name="document_file" class="form-control" accept=".pdf,image/*">
                        <p class="form-hint">Upload proof certificate, medal photo, or official report (Max 12MB). Leave blank to keep existing file.</p>
                    </div>

                    <div class="form-group" style="max-width:200px;">
                        <label for="display_order">Display Order</label>
                        <input type="number" id="display_order" name="display_order" class="form-control" min="0"
                            value="<?= (int)($editRecord['display_order'] ?? 1) ?>">
                    </div>

                    <button type="submit" class="btn btn-primary" style="font-size:0.95rem;padding:0.75rem 2rem;">
                        <i class="fas fa-save"></i> <?= $editRecord ? 'Update Record' : 'Save Record' ?>
                    </button>
                </form>

                <?php if (!empty($editRecord['document_file'])): ?>
                    <!-- Hidden form to remove attached document -->
                    <form id="removeDocForm" method="POST" action="certifications.php#editor" style="display:none;" onsubmit="return confirm('Remove attached document?');">
                        <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                        <input type="hidden" name="action" value="remove_document">
                        <input type="hidden" name="id" value="<?= (int)$editRecord['id'] ?>">
                    </form>
                <?php endif; ?>
            </div>

            <!-- Existing Records List -->
            <div class="panel">
                <div class="panel-header">
                    <span class="panel-title">Records List (<?= count($records) ?>)</span>
                    <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
                        <a href="certifications.php" class="btn btn-sm <?= empty($filterType) ? 'btn-primary' : 'btn-secondary' ?>">All</a>
                        <a href="certifications.php?filter=certification" class="btn btn-sm <?= $filterType === 'certification' ? 'btn-primary' : 'btn-secondary' ?>">Certifications</a>
                        <a href="certifications.php?filter=achievement" class="btn btn-sm <?= $filterType === 'achievement' ? 'btn-primary' : 'btn-secondary' ?>">Achievements</a>
                        <a href="certifications.php?filter=sports" class="btn btn-sm <?= $filterType === 'sports' ? 'btn-primary' : 'btn-secondary' ?>">Sports</a>
                    </div>
                </div>

                <?php if (empty($records)): ?>
                    <p style="color:var(--text-muted);">No records found under this filter.</p>
                <?php else: ?>
                    <div class="data-table-wrap">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th style="width:60px;">Order</th>
                                    <th>Category</th>
                                    <th>Title</th>
                                    <th>Organization</th>
                                    <th>Date</th>
                                    <th>Document</th>
                                    <th style="text-align:right;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($records as $r):
                                    $tInfo = $typeLabels[$r['type']] ?? $typeLabels['certification'];
                                ?>
                                    <tr>
                                        <td>
                                            <span style="display:inline-block;width:26px;height:26px;line-height:26px;text-align:center;border-radius:50%;background:var(--accent-soft);color:var(--accent);font-weight:700;font-size:0.8rem;">
                                                <?= (int)$r['display_order'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge" style="background:<?= $tInfo['bg'] ?>;color:<?= $tInfo['color'] ?>;">
                                                <i class="fas <?= $tInfo['icon'] ?>" style="margin-right:0.25rem;"></i>
                                                <?= $tInfo['label'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <strong style="color:#fff;"><?= e($r['title']) ?></strong>
                                            <?php if (!empty($r['description'])): ?>
                                                <div style="font-size:0.8rem;color:var(--text-muted);margin-top:0.2rem;">
                                                    <?= e(mb_strimwidth($r['description'], 0, 75, '...')) ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td style="color:var(--cyan);"><?= e($r['issuer_org'] ?? '—') ?></td>
                                        <td><?= e($r['date_text'] ?? '—') ?></td>
                                        <td>
                                            <?php if (!empty($r['document_file'])): ?>
                                                <a href="../uploads/certificates/<?= e($r['document_file']) ?>" target="_blank" class="btn btn-secondary btn-sm" style="font-size:0.75rem;padding:0.2rem 0.55rem;">
                                                    <i class="fas fa-file-alt" style="color:var(--cyan);"></i> View
                                                </a>
                                            <?php else: ?>
                                                <span style="color:var(--text-faint);font-size:0.8rem;">None</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align:right;">
                                            <div style="display:inline-flex;gap:0.4rem;">
                                                <a href="certifications.php?edit=<?= (int)$r['id'] ?>#editor" class="btn btn-secondary btn-sm">
                                                    <i class="fas fa-edit"></i> Edit
                                                </a>
                                                <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this record?');">
                                                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete record">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</body>
</html>
