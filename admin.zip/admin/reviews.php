<?php
// Legacy redirect: reviews replaced with Project Comments moderation
header('Location: comments.php');
exit;
