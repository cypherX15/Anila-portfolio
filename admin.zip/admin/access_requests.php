<?php
/**
 * Administrator — Project Access Requests Management
 * Handles visitor requests for restricted projects.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();
$pdo = getDBConnection();

$actionMsg = '';

// Handle Moderation Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $action = $_POST['action'] ?? '';
        $id     = (int)($_POST['id'] ?? 0);

        if ($action === 'approve' && $id > 0) {
            $pdo->prepare("UPDATE project_access_requests SET status = 'approved', updated_at = CURRENT_TIMESTAMP WHERE id = ?")->execute([$id]);
            $actionMsg = 'Access request approved. The visitor is now authorized for restricted materials.';
        }

        if ($action === 'reject' && $id > 0) {
            $pdo->prepare("UPDATE project_access_requests SET status = 'rejected', updated_at = CURRENT_TIMESTAMP WHERE id = ?")->execute([$id]);
            $actionMsg = 'Access request marked as rejected.';
        }

        if ($action === 'delete' && $id > 0) {
            $pdo->prepare("DELETE FROM project_access_requests WHERE id = ?")->execute([$id]);
            $actionMsg = 'Access request record removed.';
        }
    }
}

// Fetch all requests
$requests = $pdo->query("
    SELECT r.*, p.title AS project_title
    FROM project_access_requests r
    JOIN projects p ON r.project_id = p.id
    ORDER BY FIELD(r.status,'pending','approved','rejected'), r.created_at DESC
")->fetchAll();

$pendingCount  = count(array_filter($requests, fn($r) => $r['status'] === 'pending'));
$approvedCount = count(array_filter($requests, fn($r) => $r['status'] === 'approved'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Access Requests · Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
</head>
<body>
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <main class="admin-main">
        <header class="topbar">
            <h1 class="topbar-title">Project Access Requests</h1>
            <div style="display:flex;align-items:center;gap:1rem;">
                <span style="color:var(--warning);font-weight:600;font-size:0.9rem;">
                    <?= $pendingCount ?> Pending Requests
                </span>
            </div>
        </header>

        <div class="admin-content">
            <?php if (!empty($actionMsg)): ?>
                <div style="background:rgba(16,185,129,0.15);border:1px solid var(--accent);color:#a7f3d0;padding:1rem;border-radius:8px;margin-bottom:1.5rem;">
                    <i class="fas fa-check-circle"></i> <?= e($actionMsg) ?>
                </div>
            <?php endif; ?>

            <div class="panel">
                <div class="panel-header">
                    <h2 class="panel-title">All Access Requests (<?= count($requests) ?>)</h2>
                </div>

                <div class="data-table-wrap">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>Visitor Information</th>
                                <th>Project</th>
                                <th>Reason Given</th>
                                <th>Requested</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($requests)): ?>
                                <tr>
                                    <td colspan="6" style="text-align:center;padding:2.5rem;color:var(--text-muted);">
                                        No access requests recorded.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($requests as $r): ?>
                                    <tr style="<?= $r['status'] === 'pending' ? 'background:rgba(245,158,11,0.04);' : '' ?>">
                                        <td>
                                            <?php if ($r['status'] === 'approved'): ?>
                                                <span class="badge badge-success"><i class="fas fa-check-circle"></i> Approved</span>
                                            <?php elseif ($r['status'] === 'pending'): ?>
                                                <span class="badge badge-warning"><i class="fas fa-hourglass-half"></i> Pending</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger"><i class="fas fa-times-circle"></i> Rejected</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?= e($r['visitor_name']) ?></strong><br>
                                            <a href="mailto:<?= e($r['visitor_email']) ?>" style="color:var(--cyan);font-size:0.85rem;">
                                                <?= e($r['visitor_email']) ?>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="../project.php?id=<?= $r['project_id'] ?>" target="_blank" style="color:#fff;font-weight:600;font-size:0.88rem;">
                                                <?= e($r['project_title']) ?>
                                            </a>
                                        </td>
                                        <td style="max-width:320px;">
                                            <div style="font-size:0.88rem;color:#e5e7eb;line-height:1.5;">
                                                <?= nl2br(e($r['reason'])) ?>
                                            </div>
                                        </td>
                                        <td style="font-size:0.82rem;color:var(--text-muted);white-space:nowrap;">
                                            <?= date('M d, Y H:i', strtotime($r['created_at'])) ?>
                                        </td>
                                        <td style="white-space:nowrap;">
                                            <div style="display:flex;gap:0.4rem;">
                                                <?php if ($r['status'] !== 'approved'): ?>
                                                    <form method="POST" action="access_requests.php" style="display:inline;">
                                                        <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                        <input type="hidden" name="action" value="approve">
                                                        <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                                        <button type="submit" class="btn btn-primary btn-sm" title="Approve Access">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>

                                                <?php if ($r['status'] !== 'rejected'): ?>
                                                    <form method="POST" action="access_requests.php" style="display:inline;">
                                                        <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                        <input type="hidden" name="action" value="reject">
                                                        <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                                        <button type="submit" class="btn btn-outline btn-sm" title="Reject / Revoke">
                                                            <i class="fas fa-ban"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>

                                                <form method="POST" action="access_requests.php" onsubmit="return confirm('Delete this request permanently?');" style="display:inline;">
                                                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
