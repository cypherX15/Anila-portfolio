<?php
/**
 * Administrator — Contact Messages Inbox
 * Read, toggle read/unread status, delete inquiries.
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth_check.php';

requireAdmin();
$pdo = getDBConnection();

$actionMsg = '';

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $action = $_POST['action'] ?? '';
        $id     = (int)($_POST['id'] ?? 0);

        if ($action === 'toggle_read' && $id > 0) {
            $pdo->prepare("UPDATE contact_messages SET is_read = 1 - is_read WHERE id = ?")->execute([$id]);
            $actionMsg = 'Message status updated.';
        }

        if ($action === 'delete' && $id > 0) {
            $pdo->prepare("DELETE FROM contact_messages WHERE id = ?")->execute([$id]);
            $actionMsg = 'Message deleted.';
        }
    }
}

// Fetch all messages
$messages = $pdo->query("SELECT * FROM contact_messages ORDER BY is_read ASC, created_at DESC")->fetchAll();
$unreadCount = count(array_filter($messages, fn($m) => (int)$m['is_read'] === 0));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Messages · Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
</head>
<body>
    <?php require_once __DIR__ . '/sidebar.php'; ?>

    <main class="admin-main">
        <header class="topbar">
            <h1 class="topbar-title">Contact Inquiries Inbox</h1>
            <span style="color:var(--accent);font-weight:600;font-size:0.9rem;">
                <?= $unreadCount ?> Unread
            </span>
        </header>

        <div class="admin-content">
            <?php if (!empty($actionMsg)): ?>
                <div style="background:rgba(16,185,129,0.15);border:1px solid var(--accent);color:#a7f3d0;padding:1rem;border-radius:8px;margin-bottom:1.5rem;">
                    <i class="fas fa-check-circle"></i> <?= e($actionMsg) ?>
                </div>
            <?php endif; ?>

            <div class="panel">
                <div class="panel-header">
                    <h2 class="panel-title">Messages (<?= count($messages) ?>)</h2>
                </div>

                <div class="data-table-wrap">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>Sender</th>
                                <th>Subject &amp; Message</th>
                                <th>Received</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($messages)): ?>
                                <tr>
                                    <td colspan="5" style="text-align:center;padding:2.5rem;color:var(--text-muted);">
                                        No messages in the inbox.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($messages as $m): ?>
                                    <tr style="<?= !(int)$m['is_read'] ? 'background:rgba(16,185,129,0.04);' : '' ?>">
                                        <td>
                                            <?php if ((int)$m['is_read']): ?>
                                                <span class="badge" style="background:#374151;color:#9ca3af;">Read</span>
                                            <?php else: ?>
                                                <span class="badge badge-warning"><i class="fas fa-envelope"></i> New</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?= e($m['name']) ?></strong><br>
                                            <a href="mailto:<?= e($m['email']) ?>" style="color:var(--cyan);font-size:0.85rem;">
                                                <?= e($m['email']) ?>
                                            </a>
                                        </td>
                                        <td>
                                            <div style="font-weight:700;color:#fff;margin-bottom:0.25rem;font-size:0.95rem;">
                                                <?= e($m['subject']) ?>
                                            </div>
                                            <div style="color:var(--text-muted);font-size:0.88rem;white-space:pre-wrap;line-height:1.5;max-width:550px;">
                                                <?= e($m['message']) ?>
                                            </div>
                                        </td>
                                        <td style="font-size:0.82rem;color:var(--text-muted);white-space:nowrap;">
                                            <?= date('M d, Y H:i', strtotime($m['created_at'])) ?>
                                        </td>
                                        <td style="white-space:nowrap;">
                                            <div style="display:flex;gap:0.4rem;">
                                                <a href="mailto:<?= e($m['email']) ?>?subject=Re: <?= urlencode($m['subject']) ?>" class="btn btn-primary btn-sm" title="Reply">
                                                    <i class="fas fa-reply"></i>
                                                </a>

                                                <form method="POST" action="messages.php" style="display:inline;">
                                                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                    <input type="hidden" name="action" value="toggle_read">
                                                    <input type="hidden" name="id" value="<?= $m['id'] ?>">
                                                    <button type="submit" class="btn btn-outline btn-sm" title="Toggle Read Status">
                                                        <?= (int)$m['is_read'] ? '<i class="fas fa-envelope"></i>' : '<i class="fas fa-envelope-open"></i>' ?>
                                                    </button>
                                                </form>

                                                <form method="POST" action="messages.php" onsubmit="return confirm('Delete this message?');" style="display:inline;">
                                                    <input type="hidden" name="csrf_token" value="<?= getCsrfToken() ?>">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?= $m['id'] ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
