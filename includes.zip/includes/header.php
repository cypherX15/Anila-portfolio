<?php
require_once __DIR__ . '/auth_check.php';
$adminLoggedIn   = isAdminLoggedIn();
$currentPage     = basename($_SERVER['PHP_SELF']);
$assetBase       = isset($assetBase) ? $assetBase : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Portfolio of Anila S - Information Technology Engineer & Developer.">
    <meta name="theme-color" content="#8b5cf6">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' · ' : '' ?>Anila S</title>
    <link rel="stylesheet" href="<?= $assetBase ?>assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" referrerpolicy="no-referrer">
</head>
<body>
    <!-- Lightbox overlay for project screenshots -->
    <div class="lightbox-overlay" id="lightbox">
        <button class="lightbox-close" id="lightboxClose" title="Close">&times;</button>
        <img src="" alt="Screenshot" class="lightbox-img" id="lightboxImg">
    </div>

    <!-- Minimal Modern Navigation Bar -->
    <header class="navbar" id="mainNav">
        <div class="nav-container">
            <a href="<?= $assetBase ?>index.php" class="brand-logo">
                <span class="brand-badge"></span>
                <span>Anila S</span>
            </a>

            <nav>
                <ul class="nav-links" id="navLinks">
                    <li><a href="<?= $assetBase ?>index.php#home">Home</a></li>
                    <li><a href="<?= $assetBase ?>index.php#about">About</a></li>
                    <li><a href="<?= $assetBase ?>index.php#projects">Projects</a></li>
                    <li><a href="<?= $assetBase ?>index.php#skills">Skills</a></li>
                    <li><a href="<?= $assetBase ?>index.php#certifications">Achievements</a></li>
                    <li><a href="<?= $assetBase ?>index.php#contact">Contact</a></li>
                </ul>
            </nav>

            <div class="nav-actions">
                <?php if ($adminLoggedIn): ?>
                    <a href="<?= $assetBase ?>admin/index.php" class="btn btn-primary btn-sm">
                        <i class="fas fa-cog"></i> Admin
                    </a>
                <?php else: ?>
                    <a href="<?= $assetBase ?>admin/login.php" class="btn btn-ghost btn-sm" title="Admin Portal" style="opacity:0.6;">
                        <i class="fas fa-lock"></i>
                    </a>
                <?php endif; ?>

                <button class="mobile-toggle" id="mobileToggle" aria-label="Toggle Navigation">
                    <span></span><span></span><span></span>
                </button>
            </div>
        </div>
    </header>
