<?php
$assetBase = isset($assetBase) ? $assetBase : '';
?>
    <!-- Minimal Modern Footer -->
    <footer class="footer">
        <div class="footer-inner">
            <div class="footer-grid">
                <div>
                    <div class="footer-brand-name">
                        <span class="brand-badge" style="width:8px;height:8px;"></span>
                        Anila S
                    </div>
                    <p class="footer-brand-desc">
                        Information Technology Engineer &amp; Full-Stack Developer. Focused on building robust distributed systems, algorithmic tools, and creative digital applications.
                    </p>
                    <div class="footer-social">
                        <a href="https://github.com/cypherX15" target="_blank" rel="noopener" title="GitHub">
                            <i class="fab fa-github"></i>
                        </a>
                        <a href="mailto:anila994785@gmail.com" title="Email">
                            <i class="fas fa-envelope"></i>
                        </a>
                        <a href="Resume .pdf" download title="Resume">
                            <i class="fas fa-file-pdf"></i>
                        </a>
                    </div>
                </div>

                <div>
                    <div class="footer-col-title">Navigation</div>
                    <ul class="footer-nav-list">
                        <li><a href="<?= $assetBase ?>index.php#home">Home</a></li>
                        <li><a href="<?= $assetBase ?>index.php#about">About</a></li>
                        <li><a href="<?= $assetBase ?>index.php#projects">Featured Projects</a></li>
                        <li><a href="<?= $assetBase ?>index.php#skills">Technical Skills</a></li>
                        <li><a href="<?= $assetBase ?>index.php#contact">Contact</a></li>
                    </ul>
                </div>

                <div>
                    <div class="footer-col-title">System &amp; Access</div>
                    <ul class="footer-nav-list">
                        <li><a href="Resume .pdf" download>Download Resume (PDF)</a></li>
                        <li><a href="<?= $assetBase ?>admin/login.php">Administrator Login</a></li>
                        <li><a href="https://github.com/cypherX15" target="_blank" rel="noopener">GitHub Profile</a></li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <p class="footer-copy">
                    &copy; <?= date('Y') ?> Anila S &bull; Palakkad, Kerala, India
                </p>
                <p style="color:var(--text-muted);font-size:0.8rem;">
                    PHP &bull; MySQL &bull; Apache on XAMPP
                </p>
            </div>
        </div>
    </footer>

    <script src="<?= $assetBase ?>assets/js/main.js"></script>
</body>
</html>
