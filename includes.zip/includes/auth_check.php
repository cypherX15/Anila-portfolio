<?php
/**
 * Authentication and Session Helper
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Escapes HTML characters for safe output (XSS defense).
 */
function e(?string $str): string {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Checks if a visitor (name + email) has an active session.
 */
function isVisitorLoggedIn(): bool {
    return !empty($_SESSION['visitor_name']) && !empty($_SESSION['visitor_email']);
}

/**
 * Returns the current visitor's name.
 */
function getVisitorName(): string {
    return $_SESSION['visitor_name'] ?? 'Guest';
}

/**
 * Returns the current visitor's email.
 */
function getVisitorEmail(): string {
    return $_SESSION['visitor_email'] ?? '';
}

/**
 * Checks if the site administrator is authenticated.
 */
function isAdminLoggedIn(): bool {
    return !empty($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

/**
 * Restricts access to admin-only pages.
 */
function requireAdmin(): void {
    if (!isAdminLoggedIn()) {
        header('Location: login.php?error=unauthorized');
        exit;
    }
}

/**
 * Generates and returns a CSRF token.
 */
function getCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verifies a submitted CSRF token.
 */
function verifyCsrfToken(?string $token): bool {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}
